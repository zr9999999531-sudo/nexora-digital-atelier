/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        obsidian: {
          DEFAULT: '#0B0B0B',
          50: '#f5f5f5',
          900: '#0B0B0B',
          800: '#111111',
          700: '#161616',
          600: '#1c1c1c',
          500: '#242424',
        },
        charcoal: {
          DEFAULT: '#141414',
          light: '#1a1a1a',
          dark: '#0d0d0d',
        },
        graphite: {
          DEFAULT: '#1e1e1e',
          light: '#282828',
        },
        gold: {
          DEFAULT: '#c9a96e',
          50: '#faf6ee',
          100: '#f0e6cf',
          200: '#e0cda0',
          300: '#d4bd87',
          400: '#c9a96e',
          500: '#b8965a',
          600: '#a07e45',
          700: '#7e6336',
          800: '#5c4a28',
          900: '#3d3019',
        },
        champagne: '#e8d5a8',
        silver: {
          DEFAULT: '#c0c0c0',
          light: '#d4d4d4',
          dark: '#8a8a8a',
        },
        ivory: '#f5f0e6',
        ivorySoft: '#e8e2d6',
      },
      fontFamily: {
        serif: ['"Playfair Display"', 'Georgia', 'serif'],
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      letterSpacing: {
        'ultra-wide': '0.3em',
        'wider-2': '0.15em',
        'mega-wide': '0.5em',
      },
      animation: {
        'fade-in': 'fadeIn 1.2s cubic-bezier(0.22,1,0.36,1)',
        'fade-up': 'fadeUp 1.2s cubic-bezier(0.22,1,0.36,1)',
        'fade-up-slow': 'fadeUp 1.8s cubic-bezier(0.22,1,0.36,1)',
        'slide-down': 'slideDown 0.5s cubic-bezier(0.22,1,0.36,1)',
        'shimmer': 'shimmer 4s ease-in-out infinite',
        'float': 'float 8s ease-in-out infinite',
        'glow-pulse': 'glowPulse 6s ease-in-out infinite',
        'gradient-shift': 'gradientShift 8s ease-in-out infinite',
        'line-draw': 'lineDraw 2.5s cubic-bezier(0.22,1,0.36,1) forwards',
        'marquee': 'marquee 40s linear infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        fadeUp: {
          '0%': { opacity: '0', transform: 'translateY(32px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        slideDown: {
          '0%': { opacity: '0', transform: 'translateY(-16px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        shimmer: {
          '0%, 100%': { opacity: '0.3' },
          '50%': { opacity: '0.8' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-20px)' },
        },
        glowPulse: {
          '0%, 100%': { opacity: '0.4' },
          '50%': { opacity: '0.7' },
        },
        gradientShift: {
          '0%, 100%': { backgroundPosition: '0% 50%' },
          '50%': { backgroundPosition: '100% 50%' },
        },
        lineDraw: {
          '0%': { strokeDashoffset: '1000' },
          '100%': { strokeDashoffset: '0' },
        },
        marquee: {
          '0%': { transform: 'translateX(0%)' },
          '100%': { transform: 'translateX(-50%)' },
        },
      },
      backdropBlur: {
        xs: '2px',
      },
      transitionTimingFunction: {
        'luxury': 'cubic-bezier(0.22, 1, 0.36, 1)',
        'expensive': 'cubic-bezier(0.16, 1, 0.3, 1)',
      },
    },
  },
  plugins: [],
};
