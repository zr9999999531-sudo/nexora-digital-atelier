# NEXORA Digital Atelier

Premium web design & e-commerce studio website. Built with React, TypeScript, Vite, and Tailwind CSS.

## Tech Stack

- React 18 + TypeScript
- Vite 5 (build tool)
- Tailwind CSS 3
- React Router 7
- Lucide React (icons)

## Requirements

- Node.js 18 or higher
- npm 9 or higher

## Local Development (Windows)

1. Download and install Node.js from https://nodejs.org (choose the LTS version).

2. Open **Command Prompt** or **PowerShell**.

3. Navigate to the project folder:
   ```cmd
   cd path\to\nexora-digital-atelier
   ```

4. Install dependencies:
   ```cmd
   npm install
   ```

5. Start the development server:
   ```cmd
   npm run dev
   ```

6. Open the URL shown in the terminal (usually http://localhost:5173).

## Production Build

```cmd
npm run build
```

This generates a `dist/` folder with all static files ready to deploy.

## Preview the Production Build Locally

```cmd
npm run preview
```

## Deploy to Cloudflare Pages (Free)

### Option A: Upload via Cloudflare Dashboard

1. Run `npm run build` to generate the `dist/` folder.

2. Go to https://dash.cloudflare.com and sign in (create a free account if needed).

3. In the left sidebar, click **Workers & Pages**.

4. Click **Create application**, then **Pages**, then **Upload assets**.

5. Give your project a name (e.g., `nexora-digital-atelier`).

6. Drag and drop the entire `dist/` folder contents into the upload area.

7. Click **Deploy site**.

8. Cloudflare will give you a free `*.pages.dev` URL.

### Option B: Connect via GitHub (recommended for automatic updates)

1. Create a GitHub repository and upload all project files to it (see "Upload to GitHub" below).

2. Go to https://dash.cloudflare.com → **Workers & Pages** → **Create application** → **Pages** → **Connect to Git**.

3. Authorize Cloudflare to access your GitHub account and select your repository.

4. Configure the build settings:
   - **Framework preset:** None
   - **Build command:** `npm run build`
   - **Build output directory:** `dist`
   - **Node version:** 18 (set under Environment variables if needed)

5. Click **Save and Deploy**.

6. Cloudflare builds and deploys your site. You get a free `*.pages.dev` URL.

7. Every time you push changes to GitHub, Cloudflare automatically rebuilds and redeploys.

### SPA Routing on Cloudflare Pages

This project uses client-side routing (React Router). The included `public/_redirects` file ensures all routes resolve to `index.html` so deep links work correctly. This file is copied into `dist/` during the build automatically.

## Upload to GitHub (Windows)

1. Download and install Git from https://git-scm.com.

2. Open **PowerShell** and configure Git once:
   ```cmd
   git config --global user.name "Your Name"
   git config --global user.email "your.email@example.com"
   ```

3. Create a new repository on https://github.com (click **New**, give it a name, do not add a README).

4. In your project folder, run:
   ```cmd
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO-NAME.git
   git push -u origin main
   ```

5. When prompted, enter your GitHub username and a Personal Access Token (create one at GitHub → Settings → Developer settings → Personal access tokens).

## Project Structure

```
nexora-digital-atelier/
├── public/              # Static assets (favicon, manifest, robots, sitemap)
├── src/
│   ├── components/      # Reusable UI components
│   ├── context/         # React context (cart state)
│   ├── data/            # Site config, products, content
│   ├── lib/             # Utilities (analytics)
│   ├── pages/           # Page components
│   │   └── legal/       # Legal pages
│   ├── App.tsx          # Router + layout
│   ├── main.tsx         # Entry point
│   ├── index.css        # Global styles + Tailwind
│   └── types.ts         # TypeScript types
├── index.html           # HTML template with SEO metadata
├── package.json
├── vite.config.ts
├── tailwind.config.js
├── tsconfig.json
└── .env.example         # Environment variable template (none required)
```

## Notes

- This is a fully static website — no backend or database is required.
- The `.env` file is excluded from version control via `.gitignore`. Do not commit secrets.
- The `dist/` folder is also excluded from version control and is regenerated on every build.

## License

All rights reserved. This is a proprietary project for NEXORA Digital Atelier.
