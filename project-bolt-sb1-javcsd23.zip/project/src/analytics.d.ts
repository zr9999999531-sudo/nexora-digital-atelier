interface Gtag {
  (...args: unknown[]): void;
}

interface Window {
  dataLayer: unknown[];
  gtag?: Gtag;
  fbq?: (...args: unknown[]) => void;
  fbqQueue?: unknown[];
}

declare global {
  interface Window {
    dataLayer: unknown[];
    gtag?: Gtag;
    fbq?: (...args: unknown[]) => void;
    fbqQueue?: unknown[];
  }
}

export {};
