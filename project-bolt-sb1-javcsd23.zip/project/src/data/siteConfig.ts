export const siteConfig = {
  name: 'NEXORA',
  fullName: 'NEXORA Digital Atelier',
  tagline: 'Premium Websites. Powerful Online Stores.',
  email: 'hello@nexoradigital.com',
  phone: '',
  whatsapp: '',
  address: 'Lahore, Pakistan',
  currency: 'USD',
  social: {
    instagram: '',
    twitter: '',
    linkedin: '',
    behance: '',
  },
  analytics: {
    ga4Id: '',
    adsConversionId: '',
    metaPixelId: '',
    enabled: false,
  },
};

export const navLinks = [
  { label: 'Home', path: '/' },
  { label: 'About', path: '/about' },
  { label: 'Services', path: '/services/website-design', children: [
    { label: 'Website Design', path: '/services/website-design' },
    { label: 'Custom Website Development', path: '/services/custom-website-development' },
    { label: 'E-Commerce Development', path: '/services/ecommerce-development' },
    { label: 'WordPress Development', path: '/services/wordpress-development' },
    { label: 'Website Redesign', path: '/services/website-redesign' },
    { label: 'SEO Foundations', path: '/services/seo-foundations' },
  ]},
  { label: 'Shop', path: '/shop', children: [
    { label: 'All Digital Products', path: '/shop' },
    { label: 'Website Templates', path: '/shop/website-templates' },
    { label: 'E-Commerce Templates', path: '/shop/ecommerce-templates' },
  ]},
  { label: 'Portfolio', path: '/portfolio' },
  { label: 'Pricing', path: '/pricing' },
  { label: 'Blog', path: '/blog' },
  { label: 'Contact', path: '/contact' },
];

export const landingPageLinks = [
  { label: 'Premium Business Website Design', path: '/lp/premium-website-design' },
  { label: 'Custom E-Commerce Store Development', path: '/lp/custom-ecommerce-store' },
  { label: 'Luxury Website Templates', path: '/lp/luxury-website-templates' },
  { label: 'Online Store Templates', path: '/lp/online-store-templates' },
  { label: 'Professional Website Redesign', path: '/lp/professional-website-redesign' },
];
