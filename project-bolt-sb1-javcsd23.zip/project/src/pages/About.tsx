import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import SectionHeading from '@/components/SectionHeading';
import Reveal from '@/components/Reveal';

const values = [
  { num: '01', title: 'Craft Over Volume', desc: 'We prioritize quality over quantity. Every project receives the attention it deserves, from concept to final delivery.' },
  { num: '02', title: 'International by Design', desc: 'Our work is built for global audiences — responsive, accessible, and optimized for cross-border performance.' },
  { num: '03', title: 'Honesty First', desc: 'We do not make promises we cannot keep. No fabricated results, no false guarantees, no hidden costs.' },
  { num: '04', title: 'Engineering Excellence', desc: 'Clean, maintainable code is the foundation of every product we build and every template we sell.' },
];

const stats = [
  { value: '24', label: 'Digital Products' },
  { value: '8', label: 'Industries Covered' },
  { value: '6', label: 'Service Categories' },
  { value: '100%', label: 'USD Pricing' },
];

export default function About() {
  return (
    <div className="pt-32 pb-32 min-h-screen">
      {/* Hero */}
      <Reveal>
        <section className="container-lux-full mb-24">
          <div className="max-w-4xl">
            <p className="eyebrow mb-6">
              <span className="inline-block w-6 h-px bg-gold/30 align-middle mr-3" />
              About NEXORA
            </p>
            <h1 className="heading-display text-4xl md:text-5xl lg:text-7xl mb-8 text-balance">
              A Digital Atelier for
              <br />
              <span className="text-gradient-gold italic font-normal">Ambitious Brands</span>
            </h1>
            <p className="text-lg text-ivorySoft/50 font-sans font-light leading-relaxed max-w-2xl">
              NEXORA Digital Atelier is a luxury web design and development studio crafting premium digital experiences for businesses worldwide. From custom website design to complete e-commerce platforms and ready-made digital products, we help brands build a stronger online presence.
            </p>
          </div>
        </section>
      </Reveal>

      {/* Stats */}
      <Reveal delay={100}>
        <section className="container-lux-full mb-24">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-px bg-white/[0.04]">
            {stats.map((s) => (
              <div key={s.label} className="bg-charcoal-dark p-10 text-center hover:bg-white/[0.01] transition-all duration-700 ease-luxury group">
                <p className="font-serif text-4xl md:text-5xl text-gold mb-2 group-hover:text-champagne transition-colors duration-700">{s.value}</p>
                <p className="text-[10px] uppercase tracking-wider-2 text-ivorySoft/40 font-sans font-light">{s.label}</p>
              </div>
            ))}
          </div>
        </section>
      </Reveal>

      {/* Story */}
      <Reveal>
        <section className="container-lux-full mb-24">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <SectionHeading eyebrow="Our Story" title="Built on Craft and Honesty" />
              <div className="space-y-5 text-sm text-ivorySoft/50 font-sans font-light leading-relaxed mt-8">
                <p>
                  NEXORA was founded with a simple conviction: that every business deserves a digital presence that reflects the quality of what they do. Too many websites are forgettable, generic, or broken. We exist to change that.
                </p>
                <p>
                  We approach web design as a craft, not a commodity. Whether we are building a custom website for a professional services firm or creating a ready-made template for a fashion brand, the same principles apply: refined typography, purposeful layout, honest content, and code that performs.
                </p>
                <p>
                  Based in Pakistan and serving clients internationally, we bring a global perspective to every project. All our prices are in USD, our work is responsive across devices, and our process is transparent from first conversation to final delivery.
                </p>
              </div>
            </div>
            <div className="relative aspect-[4/3] overflow-hidden surface-card">
              <img src="https://images.pexels.com/photos/1170412/pexels-photo-1170412.jpeg?auto=compress&cs=tinysrgb&h=800&w=1200" alt="Modern workspace" className="w-full h-full object-cover opacity-70" />
              <div className="absolute inset-0 bg-gradient-to-t from-obsidian/60 to-transparent" />
            </div>
          </div>
        </section>
      </Reveal>

      {/* Values */}
      <Reveal>
        <section className="container-lux-full mb-24">
          <SectionHeading eyebrow="What We Stand For" title="Our Values" center />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-white/[0.04] mt-16">
            {values.map((v) => (
              <div key={v.title} className="bg-charcoal-dark p-10 h-full hover:bg-white/[0.01] transition-all duration-700 ease-luxury group">
                <span className="font-serif text-3xl text-gold/20 block mb-6">{v.num}</span>
                <div className="h-px w-10 bg-gold/25 mb-6 group-hover:w-16 transition-all duration-700 ease-luxury" />
                <h3 className="font-serif text-lg text-ivory mb-4">{v.title}</h3>
                <p className="text-xs text-ivorySoft/40 font-sans font-light leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>
        </section>
      </Reveal>

      {/* CTA */}
      <Reveal>
        <section className="container-lux text-center">
          <SectionHeading
            eyebrow="Get Started"
            title="Let's Build Something Exceptional"
            subtitle="Whether you need a custom-built website or a ready-made template, we are ready to help."
            center
          />
          <div className="flex flex-col sm:flex-row gap-4 justify-center mt-12">
            <Link to="/project-inquiry" className="btn-primary">
              Start Your Project <ArrowRight size={16} />
            </Link>
            <Link to="/shop" className="btn-outline">
              Browse Products
            </Link>
          </div>
        </section>
      </Reveal>
    </div>
  );
}
