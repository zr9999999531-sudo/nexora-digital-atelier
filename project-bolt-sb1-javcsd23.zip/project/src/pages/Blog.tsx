import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';
import { blogPosts, blogCategories } from '@/data/content';
import Reveal from '@/components/Reveal';

export default function Blog() {
  const [category, setCategory] = useState('All');
  const [search, setSearch] = useState('');

  const filtered = useMemo(() => {
    let posts = [...blogPosts];
    if (category !== 'All') posts = posts.filter((p) => p.category === category);
    if (search) {
      const q = search.toLowerCase();
      posts = posts.filter((p) => p.title.toLowerCase().includes(q) || p.excerpt.toLowerCase().includes(q));
    }
    return posts;
  }, [category, search]);

  return (
    <div className="pt-32 pb-32 min-h-screen">
      <div className="container-lux-full">
        <Reveal>
          <div className="text-center mb-16">
            <p className="eyebrow mb-5">
              <span className="inline-block w-6 h-px bg-gold/30 align-middle mr-3" />
              Insights & Articles
            </p>
            <h1 className="heading-display text-4xl md:text-5xl lg:text-6xl mb-6">Blog</h1>
            <p className="text-sm text-ivorySoft/45 font-sans font-light max-w-2xl mx-auto leading-relaxed">
              Thoughts on website design, e-commerce, WordPress, performance, digital business, and SEO foundations.
            </p>
          </div>
        </Reveal>

        <Reveal delay={100}>
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-12">
            <div className="flex flex-wrap gap-2">
              {blogCategories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategory(cat)}
                  className={`tag-lux transition-all duration-500 ease-luxury ${category === cat ? '!bg-gold/10 !border-gold/40 !text-gold' : 'hover:!border-gold/25'}`}
                >
                  {cat}
                </button>
              ))}
            </div>
            <input
              type="text"
              placeholder="Search articles..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="input-lux !py-2.5 md:w-64"
            />
          </div>
        </Reveal>

        {filtered.length === 0 ? (
          <div className="glass p-20 text-center rounded-sm">
            <p className="text-sm text-ivorySoft/40 font-sans font-light">No articles match your search.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((post, i) => (
              <Reveal key={post.id} delay={(i % 3) * 100}>
                <Link
                  to={`/blog/${post.slug}`}
                  className="group surface-card overflow-hidden hover:border-gold/20 transition-all duration-700 ease-luxury flex flex-col"
                >
                  <div className="relative aspect-[16/10] overflow-hidden bg-obsidian">
                    <img src={post.image} alt={post.title} loading="lazy" className="w-full h-full object-cover transition-transform duration-[1.2s] ease-luxury group-hover:scale-[1.06] opacity-85 group-hover:opacity-100" />
                    <div className="absolute inset-0 bg-gradient-to-t from-obsidian/60 to-transparent" />
                    <div className="absolute top-4 left-4 tag-lux">{post.category}</div>
                  </div>
                  <div className="p-6 flex flex-col flex-1">
                    <p className="text-[10px] uppercase tracking-wider-2 text-ivorySoft/30 font-sans font-light mb-2">{post.date} · {post.readTime}</p>
                    <h3 className="font-serif text-lg text-ivory mb-3 group-hover:text-gold transition-colors duration-700 ease-luxury">{post.title}</h3>
                    <p className="text-xs text-ivorySoft/40 font-sans font-light leading-relaxed flex-1">{post.excerpt}</p>
                    <span className="link-arrow mt-4 group/link">
                      Read Article <ArrowUpRight size={12} className="group-hover/link:translate-x-0.5 group-hover/link:-translate-y-0.5 transition-transform duration-500 ease-luxury" />
                    </span>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
