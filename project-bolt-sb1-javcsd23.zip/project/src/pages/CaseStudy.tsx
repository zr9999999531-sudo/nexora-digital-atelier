import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import { portfolioItems } from '@/data/content';
import Reveal from '@/components/Reveal';

export default function CaseStudy() {
  const { slug } = useParams<{ slug: string }>();
  const item = portfolioItems.find((p) => p.slug === slug);

  if (!item) {
    return (
      <div className="pt-32 pb-24 min-h-screen">
        <div className="container-lux text-center">
          <h1 className="heading-display text-4xl mb-8">Case Study Not Found</h1>
          <Link to="/portfolio" className="btn-primary">
            <ArrowLeft size={16} /> Back to Portfolio
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-32 pb-32 min-h-screen">
      <div className="container-lux max-w-4xl">
        <Reveal>
          <Link to="/portfolio" className="link-arrow mb-10 group">
            <ArrowLeft size={14} className="group-hover:-translate-x-1 transition-transform duration-500 ease-luxury" />
            Back to Portfolio
          </Link>
        </Reveal>

        <Reveal delay={100}>
          {item.isConcept && (
            <div className="tag-lux mb-6">Concept Project</div>
          )}
          <p className="text-[10px] uppercase tracking-wider-2 text-gold/50 font-sans font-light mb-3">{item.category} · {item.year}</p>
          <h1 className="heading-display text-4xl md:text-5xl lg:text-6xl mb-6">{item.title}</h1>
          <p className="text-lg text-ivorySoft/50 font-sans font-light leading-relaxed mb-12">{item.excerpt}</p>
        </Reveal>

        <Reveal delay={200}>
          <div className="relative aspect-[16/9] overflow-hidden surface-card rounded-sm mb-16">
            <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-obsidian/40 to-transparent" />
          </div>
        </Reveal>

        <Reveal delay={300}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-white/[0.04] mb-16">
            <div className="bg-charcoal-dark p-6">
              <p className="text-[10px] uppercase tracking-wider-2 text-gold/50 font-sans font-light mb-2">Client</p>
              <p className="text-sm text-ivorySoft/70 font-sans font-light">{item.client}</p>
            </div>
            <div className="bg-charcoal-dark p-6">
              <p className="text-[10px] uppercase tracking-wider-2 text-gold/50 font-sans font-light mb-2">Year</p>
              <p className="text-sm text-ivorySoft/70 font-sans font-light">{item.year}</p>
            </div>
            <div className="bg-charcoal-dark p-6">
              <p className="text-[10px] uppercase tracking-wider-2 text-gold/50 font-sans font-light mb-2">Services</p>
              <p className="text-sm text-ivorySoft/70 font-sans font-light">{item.services.join(', ')}</p>
            </div>
          </div>
        </Reveal>

        <Reveal delay={400}>
          <div className="mb-16">
            <h2 className="font-serif text-2xl text-ivory mb-4">Project Overview</h2>
            <p className="text-sm text-ivorySoft/55 font-sans font-light leading-relaxed">{item.description}</p>
          </div>
        </Reveal>

        <Reveal delay={500}>
          <div className="glass-elevated p-10 text-center rounded-sm">
            <h3 className="font-serif text-xl text-ivory mb-3">Want a Similar Project?</h3>
            <p className="text-sm text-ivorySoft/45 font-sans font-light mb-8">We can build something tailored to your brand and industry.</p>
            <Link to="/project-inquiry" className="btn-primary">
              Start Your Project <ArrowRight size={16} />
            </Link>
          </div>
        </Reveal>
      </div>
    </div>
  );
}
