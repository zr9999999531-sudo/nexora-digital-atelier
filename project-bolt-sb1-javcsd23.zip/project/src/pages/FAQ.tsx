import { useState } from 'react';
import { faqItems, faqCategories } from '@/data/content';
import Reveal from '@/components/Reveal';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

export default function FAQ() {
  const [activeCategory, setActiveCategory] = useState('All');

  const filtered = activeCategory === 'All'
    ? faqItems
    : faqItems.filter((f) => f.category === activeCategory);

  return (
    <div className="pt-32 pb-32 min-h-screen">
      <div className="container-lux max-w-3xl">
        <Reveal>
          <div className="text-center mb-16">
            <p className="eyebrow mb-5">
              <span className="inline-block w-6 h-px bg-gold/30 align-middle mr-3" />
              Help Center
            </p>
            <h1 className="heading-display text-4xl md:text-5xl lg:text-6xl mb-6">Frequently Asked</h1>
            <p className="text-sm text-ivorySoft/45 font-sans font-light leading-relaxed">
              Answers to common questions about our services, digital products, payments, and policies.
            </p>
          </div>
        </Reveal>

        <Reveal delay={100}>
          <div className="flex flex-wrap justify-center gap-2 mb-12">
            {faqCategories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`tag-lux transition-all duration-500 ease-luxury ${activeCategory === cat ? '!bg-gold/10 !border-gold/40 !text-gold' : 'hover:!border-gold/25'}`}
              >
                {cat}
              </button>
            ))}
          </div>
        </Reveal>

        <div className="space-y-px bg-white/[0.04] mb-16">
          {filtered.map((faq, i) => (
            <Reveal key={i} delay={(i % 4) * 60}>
              <details className="group bg-charcoal-dark cursor-pointer">
                <summary className="flex items-center justify-between list-none p-6 lg:p-8">
                  <div>
                    <span className="text-[10px] uppercase tracking-wider-2 text-gold/40 font-sans font-light block mb-1">{faq.category}</span>
                    <span className="font-serif text-base lg:text-lg text-ivory pr-4">{faq.question}</span>
                  </div>
                  <span className="text-gold/50 text-2xl font-light group-open:rotate-45 transition-transform duration-500 ease-luxury shrink-0 ml-4">+</span>
                </summary>
                <p className="px-6 lg:px-8 pb-6 lg:pb-8 text-sm text-ivorySoft/45 font-sans font-light leading-relaxed">{faq.answer}</p>
              </details>
            </Reveal>
          ))}
        </div>

        <Reveal>
          <div className="glass-elevated p-10 text-center rounded-sm">
            <h2 className="font-serif text-2xl text-ivory mb-3">Still Have Questions?</h2>
            <p className="text-sm text-ivorySoft/45 font-sans font-light mb-8">We're here to help. Reach out and we'll get back to you.</p>
            <Link to="/contact" className="btn-primary">
              Contact Us <ArrowRight size={16} />
            </Link>
          </div>
        </Reveal>
      </div>
    </div>
  );
}
