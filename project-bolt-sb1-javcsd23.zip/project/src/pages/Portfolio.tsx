import { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';
import { portfolioItems, portfolioCategories } from '@/data/content';
import Reveal from '@/components/Reveal';

export default function Portfolio() {
  const [category, setCategory] = useState('All');

  const filtered = useMemo(() => {
    if (category === 'All') return portfolioItems;
    return portfolioItems.filter((p) => p.category === category);
  }, [category]);

  return (
    <div className="pt-32 pb-32 min-h-screen">
      <div className="container-lux-full">
        {/* Header */}
        <Reveal>
          <div className="text-center mb-16">
            <p className="eyebrow mb-5">
              <span className="inline-block w-6 h-px bg-gold/30 align-middle mr-3" />
              Our Work
            </p>
            <h1 className="heading-display text-4xl md:text-5xl lg:text-6xl mb-6">Portfolio</h1>
            <p className="text-sm text-ivorySoft/45 font-sans font-light max-w-2xl mx-auto leading-relaxed">
              A selection of concept projects demonstrating our approach to luxury digital design across industries. All entries are labeled as concept work.
            </p>
          </div>
        </Reveal>

        {/* Filters */}
        <Reveal delay={100}>
          <div className="flex flex-wrap justify-center gap-2 mb-16">
            {portfolioCategories.map((cat) => (
              <button
                key={cat}
                onClick={() => setCategory(cat)}
                className={`tag-lux transition-all duration-500 ease-luxury ${category === cat ? '!bg-gold/10 !border-gold/40 !text-gold' : 'hover:!border-gold/25'}`}
              >
                {cat}
              </button>
            ))}
          </div>
        </Reveal>

        {/* Grid */}
        {filtered.length === 0 ? (
          <div className="glass p-20 text-center">
            <p className="text-sm text-ivorySoft/40 font-sans font-light">No projects in this category yet.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((item, i) => (
              <Reveal key={item.id} delay={(i % 3) * 120}>
                <Link
                  to={`/portfolio/${item.slug}`}
                  className="group surface-card overflow-hidden hover:border-gold/20 transition-all duration-700 ease-luxury flex flex-col"
                >
                  <div className="relative aspect-[4/3] overflow-hidden bg-obsidian">
                    <img
                      src={item.image}
                      alt={item.title}
                      loading="lazy"
                      className="w-full h-full object-cover transition-transform duration-[1.2s] ease-luxury group-hover:scale-[1.06] opacity-85 group-hover:opacity-100"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-obsidian/80 via-transparent to-transparent" />
                    {item.isConcept && (
                      <div className="absolute top-4 left-4 tag-lux">Concept</div>
                    )}
                  </div>
                  <div className="p-6 flex flex-col flex-1">
                    <p className="text-[10px] uppercase tracking-wider-2 text-gold/50 font-sans font-light mb-2">{item.category} · {item.year}</p>
                    <h3 className="font-serif text-xl text-ivory mb-3 group-hover:text-gold transition-colors duration-700 ease-luxury">{item.title}</h3>
                    <p className="text-xs text-ivorySoft/40 font-sans font-light leading-relaxed flex-1">{item.excerpt}</p>
                    <span className="link-arrow mt-4 group/link">
                      View Case Study <ArrowUpRight size={12} className="group-hover/link:translate-x-0.5 group-hover/link:-translate-y-0.5 transition-transform duration-500 ease-luxury" />
                    </span>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
