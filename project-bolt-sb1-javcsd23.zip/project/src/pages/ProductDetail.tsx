import { useParams, Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { ArrowLeft, ArrowRight, Check, Download, FileText, Shield, Code2, Monitor, Smartphone, Package } from 'lucide-react';
import { getProductBySlug, getRelatedProducts } from '@/data/products';
import { useCart } from '@/context/CartContext';
import ProductCard from '@/components/ProductCard';
import Reveal from '@/components/Reveal';

export default function ProductDetail() {
  const { slug } = useParams<{ slug: string }>();
  const product = slug ? getProductBySlug(slug) : undefined;
  const { addItem } = useCart();
  const navigate = useNavigate();
  const [activeImage, setActiveImage] = useState(0);
  const [added, setAdded] = useState(false);

  if (!product) {
    return (
      <div className="pt-32 pb-24 min-h-screen">
        <div className="container-lux text-center">
          <h1 className="heading-display text-4xl mb-6">Product Not Found</h1>
          <p className="text-sm text-ivorySoft/45 mb-8 font-sans font-light">The product you are looking for does not exist or has been removed.</p>
          <Link to="/shop" className="btn-primary">
            <ArrowLeft size={16} /> Back to Shop
          </Link>
        </div>
      </div>
    );
  }

  const related = getRelatedProducts(product, 3);

  const handleAddToCart = () => {
    addItem(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const handleBuyNow = () => {
    addItem(product);
    navigate('/checkout');
  };

  return (
    <div className="pt-32 pb-32 min-h-screen">
      <div className="container-lux-full">
        <Reveal>
          <Link to="/shop" className="link-arrow mb-10 group">
            <ArrowLeft size={14} className="group-hover:-translate-x-1 transition-transform duration-500 ease-luxury" />
            Back to Shop
          </Link>
        </Reveal>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-24">
          {/* Gallery */}
          <Reveal>
            <div>
              <div className="relative aspect-[4/3] surface-card overflow-hidden mb-4 rounded-sm">
                <img src={product.gallery[activeImage]} alt={product.name} className="w-full h-full object-cover" />
                <div className="absolute top-4 left-4 tag-lux">
                  {product.category === 'website' ? 'Website Template' : 'E-Commerce Template'}
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                {product.gallery.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImage(i)}
                    className={`aspect-[4/3] overflow-hidden border transition-all duration-500 ease-luxury ${
                      activeImage === i ? 'border-gold/40' : 'border-white/[0.06] hover:border-gold/20'
                    }`}
                  >
                    <img src={img} alt={`${product.name} preview ${i + 1}`} className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>
          </Reveal>

          {/* Details */}
          <Reveal delay={100}>
            <div>
              <p className="text-[10px] uppercase tracking-wider-2 text-gold/50 font-sans font-light mb-2">{product.industry}</p>
              <h1 className="heading-display text-3xl md:text-4xl mb-4">{product.name}</h1>
              <p className="text-sm text-ivorySoft/50 font-sans font-light leading-relaxed mb-6">{product.shortDescription}</p>
              <p className="font-serif text-4xl text-gold mb-10">{product.priceLabel}</p>

              <div className="flex flex-col sm:flex-row gap-3 mb-8">
                <button onClick={handleAddToCart} className="btn-outline flex-1">
                  {added ? <><Check size={16} /> Added to Cart</> : 'Add to Cart'}
                </button>
                <button onClick={handleBuyNow} className="btn-primary flex-1">
                  Buy Now <ArrowRight size={16} />
                </button>
              </div>

              {product.demoUrl && (
                <a href={product.demoUrl} target="_blank" rel="noopener noreferrer" className="btn-ghost w-full mb-8">
                  View Live Demo <ArrowRight size={14} />
                </a>
              )}

              <div className="space-y-3 mb-8">
                {[
                  { icon: Download, text: 'Instant digital download after verified payment' },
                  { icon: Shield, text: '30 days email support included' },
                  { icon: FileText, text: 'Complete source code, assets, and documentation' },
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-3 text-sm font-sans font-light text-ivorySoft/60">
                    <item.icon size={16} strokeWidth={1.5} className="text-gold/50" />
                    {item.text}
                  </div>
                ))}
              </div>

              <div className="divider-gold mb-6" />
              <div className="grid grid-cols-2 gap-4 text-xs font-sans font-light">
                <div><span className="text-ivorySoft/30">Category:</span> <span className="text-ivorySoft/70">{product.category === 'website' ? 'Website Template' : 'E-Commerce Template'}</span></div>
                <div><span className="text-ivorySoft/30">Industry:</span> <span className="text-ivorySoft/70">{product.industry}</span></div>
                <div><span className="text-ivorySoft/30">Technology:</span> <span className="text-ivorySoft/70">{product.technology.join(', ')}</span></div>
                <div><span className="text-ivorySoft/30">License:</span> <span className="text-ivorySoft/70">Single-site commercial</span></div>
              </div>
            </div>
          </Reveal>
        </div>

        {/* Detailed Description */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 mb-24">
          <Reveal className="lg:col-span-2">
            <div>
              <h2 className="heading-display text-2xl mb-6">Overview</h2>
              <p className="text-sm text-ivorySoft/55 font-sans font-light leading-relaxed mb-8">{product.description}</p>

              <h3 className="font-serif text-xl text-ivory mb-4">Intended Audience</h3>
              <p className="text-sm text-ivorySoft/55 font-sans font-light leading-relaxed mb-8">{product.audience}</p>

              <h3 className="font-serif text-xl text-ivory mb-4">Features</h3>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-8">
                {product.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm font-sans font-light text-ivorySoft/60">
                    <Check size={14} strokeWidth={1.5} className="text-gold/50 mt-0.5 shrink-0" /> {feature}
                  </li>
                ))}
              </ul>

              <h3 className="font-serif text-xl text-ivory mb-4">Included Pages</h3>
              <div className="flex flex-wrap gap-2 mb-8">
                {product.includedPages.map((page, i) => (
                  <span key={i} className="tag-lux">{page}</span>
                ))}
              </div>

              <h3 className="font-serif text-xl text-ivory mb-4">Technology & Framework</h3>
              <div className="flex flex-wrap gap-2 mb-8">
                {product.technology.map((tech, i) => (
                  <span key={i} className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-sans font-light text-ivorySoft/60 border border-white/[0.08]">
                    <Code2 size={12} strokeWidth={1.5} className="text-gold/40" /> {tech}
                  </span>
                ))}
              </div>

              <h3 className="font-serif text-xl text-ivory mb-4">Responsive Design</h3>
              <div className="flex items-center gap-4 mb-8">
                <Monitor size={20} strokeWidth={1.5} className="text-gold/50" />
                <Smartphone size={20} strokeWidth={1.5} className="text-gold/50" />
                <p className="text-sm text-ivorySoft/55 font-sans font-light leading-relaxed flex-1">{product.responsive}</p>
              </div>

              <h3 className="font-serif text-xl text-ivory mb-4">Installation & Setup</h3>
              <div className="glass p-6 mb-8 rounded-sm">
                <p className="text-sm text-ivorySoft/55 font-sans font-light leading-relaxed whitespace-pre-line">{product.installation}</p>
              </div>
            </div>
          </Reveal>

          <Reveal delay={100}>
            <div className="space-y-6">
              <div className="glass p-6 rounded-sm">
                <h3 className="font-serif text-lg text-ivory mb-4 flex items-center gap-2">
                  <Package size={18} strokeWidth={1.5} className="text-gold/50" /> Included Files
                </h3>
                <ul className="space-y-3">
                  {product.files.map((file, i) => (
                    <li key={i} className="flex items-center justify-between text-xs font-sans font-light">
                      <div>
                        <p className="text-ivorySoft/70">{file.name}</p>
                        <p className="text-ivorySoft/30">{file.type}</p>
                      </div>
                      <span className="text-ivorySoft/30">{file.size}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="glass p-6 rounded-sm">
                <h3 className="font-serif text-lg text-ivory mb-3">Delivery</h3>
                <p className="text-xs text-ivorySoft/45 font-sans font-light leading-relaxed mb-5">{product.delivery}</p>
                <h3 className="font-serif text-lg text-ivory mb-3">Support</h3>
                <p className="text-xs text-ivorySoft/45 font-sans font-light leading-relaxed mb-5">{product.support}</p>
                <h3 className="font-serif text-lg text-ivory mb-3">License</h3>
                <p className="text-xs text-ivorySoft/45 font-sans font-light leading-relaxed">{product.license}</p>
              </div>
            </div>
          </Reveal>
        </div>

        {/* Related */}
        {related.length > 0 && (
          <Reveal>
            <div>
              <h2 className="heading-display text-2xl mb-8">Related Products</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {related.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            </div>
          </Reveal>
        )}
      </div>
    </div>
  );
}
