import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import Reveal from '@/components/Reveal';

export default function Terms() {
  return (
    <div className="pt-32 pb-32 min-h-screen">
      <div className="container-lux max-w-3xl">
        <Reveal>
          <Link to="/" className="link-arrow mb-8 group">
            <ArrowLeft size={14} className="group-hover:-translate-x-1 transition-transform duration-500 ease-luxury" />
            Back to Home
          </Link>
          <p className="eyebrow mb-5"><span className="inline-block w-6 h-px bg-gold/30 align-middle mr-3" />Legal</p>
          <h1 className="heading-display text-4xl md:text-5xl mb-4">Terms & Conditions</h1>
          <p className="text-xs text-ivorySoft/30 font-sans font-light mb-10">Last updated: October 2025. This document is a template and should be reviewed by a legal professional for your specific jurisdiction.</p>
        </Reveal>

        <Reveal delay={100}>
          <div className="space-y-8 text-sm text-ivorySoft/55 font-sans font-light leading-relaxed">
            <section>
              <h2 className="font-serif text-xl text-ivory mb-3">1. Acceptance of Terms</h2>
              <p>By accessing and using the NEXORA Digital Atelier website, you accept and agree to be bound by these Terms and Conditions. If you do not agree, please do not use our website or services.</p>
            </section>
            <section>
              <h2 className="font-serif text-xl text-ivory mb-3">2. Services</h2>
              <p>NEXORA Digital Atelier provides custom web design, e-commerce development, WordPress development, website redesign, and SEO foundation services. We also sell digital products including website templates and e-commerce templates. All services are subject to the specific terms agreed upon in each project proposal.</p>
            </section>
            <section>
              <h2 className="font-serif text-xl text-ivory mb-3">3. Digital Product License</h2>
              <p>Each digital product is licensed for use on a single website (single-site commercial license). You may modify the product for your own use. You may not resell, redistribute, sublicense, or transfer the product to third parties. Bulk or extended licenses may be available upon request.</p>
            </section>
            <section>
              <h2 className="font-serif text-xl text-ivory mb-3">4. Pricing and Payment</h2>
              <p>All prices are displayed in US Dollars (USD) and are applicable to all customers worldwide. We do not convert prices based on location. Payment for digital products is processed at checkout. Payment for custom services is agreed upon in the project proposal. Additional costs for domains, hosting, plugins, and third-party services are not included.</p>
            </section>
            <section>
              <h2 className="font-serif text-xl text-ivory mb-3">5. Custom Service Projects</h2>
              <p>For custom development projects, a project proposal will be provided after reviewing your inquiry. The proposal will include scope, deliverables, timeline, and pricing. Work begins only after you approve the proposal. Revision rounds are specified in each package.</p>
            </section>
            <section>
              <h2 className="font-serif text-xl text-ivory mb-3">6. No Guarantees</h2>
              <p>We do not guarantee specific search engine rankings, sales figures, conversion rates, or business results. SEO performance, e-commerce success, and business outcomes depend on many factors beyond website design, including content strategy, market competition, and marketing efforts.</p>
            </section>
            <section>
              <h2 className="font-serif text-xl text-ivory mb-3">7. Intellectual Property</h2>
              <p>Custom website code developed for your project is transferred to you upon final payment. Digital products remain the intellectual property of NEXORA Digital Atelier and are licensed, not sold. Third-party libraries and assets included in products are subject to their respective licenses.</p>
            </section>
            <section>
              <h2 className="font-serif text-xl text-ivory mb-3">8. Limitation of Liability</h2>
              <p>NEXORA Digital Atelier shall not be liable for any indirect, incidental, special, or consequential damages arising from the use of our website, services, or products. Our total liability shall not exceed the amount paid for the specific product or service in question.</p>
            </section>
            <section>
              <h2 className="font-serif text-xl text-ivory mb-3">9. Governing Law</h2>
              <p>These terms are governed by the laws of Pakistan. Any disputes shall be resolved in accordance with Pakistani law, unless otherwise agreed in a specific project contract.</p>
            </section>
            <section>
              <h2 className="font-serif text-xl text-ivory mb-3">10. Changes to Terms</h2>
              <p>We reserve the right to update these Terms and Conditions at any time. Changes will be posted on this page with an updated date.</p>
            </section>
          </div>
        </Reveal>

        <Reveal delay={200}>
          <div className="glass p-6 mt-10 rounded-sm">
            <p className="text-xs text-ivorySoft/30 font-sans font-light leading-relaxed">
              <strong className="text-ivorySoft/50">Note:</strong> These Terms and Conditions are a general template. They should be reviewed and customized by a qualified legal professional to ensure enforceability in your jurisdiction.
            </p>
          </div>
        </Reveal>
      </div>
    </div>
  );
}
