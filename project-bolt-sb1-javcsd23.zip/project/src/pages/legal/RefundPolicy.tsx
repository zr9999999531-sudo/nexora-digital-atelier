import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import Reveal from '@/components/Reveal';

export default function RefundPolicy() {
  return (
    <div className="pt-32 pb-32 min-h-screen">
      <div className="container-lux max-w-3xl">
        <Reveal>
          <Link to="/" className="link-arrow mb-8 group">
            <ArrowLeft size={14} className="group-hover:-translate-x-1 transition-transform duration-500 ease-luxury" />
            Back to Home
          </Link>
          <p className="eyebrow mb-5"><span className="inline-block w-6 h-px bg-gold/30 align-middle mr-3" />Legal</p>
          <h1 className="heading-display text-4xl md:text-5xl mb-4">Refund & Digital Product Policy</h1>
          <p className="text-xs text-ivorySoft/30 font-sans font-light mb-10">Last updated: October 2025. This document is a template and should be reviewed by a legal professional for your specific jurisdiction.</p>
        </Reveal>

        <Reveal delay={100}>
          <div className="space-y-8 text-sm text-ivorySoft/55 font-sans font-light leading-relaxed">
            <section>
              <h2 className="font-serif text-xl text-ivory mb-3">1. Digital Product Refunds</h2>
              <p>Due to the nature of digital products — which can be downloaded and duplicated immediately after purchase — all digital product sales are final once the download has been accessed. We do not offer refunds for digital products that have been downloaded.</p>
            </section>
            <section>
              <h2 className="font-serif text-xl text-ivory mb-3">2. Technical Issues</h2>
              <p>If you experience technical issues with a digital product that prevent it from functioning as described, please contact us within 30 days of purchase. We will provide technical support to resolve the issue or, if the issue cannot be resolved, offer a replacement product of equal value.</p>
            </section>
            <section>
              <h2 className="font-serif text-xl text-ivory mb-3">3. Product Not As Described</h2>
              <p>If a digital product significantly differs from its description on our website, please contact us within 14 days of purchase. We will review your claim and, if valid, offer a refund or replacement at our discretion.</p>
            </section>
            <section>
              <h2 className="font-serif text-xl text-ivory mb-3">4. Custom Service Deposits</h2>
              <p>For custom development projects, any deposit or advance payment is non-refundable once work has commenced. If the project is cancelled before work begins, the deposit may be refunded at our discretion.</p>
            </section>
            <section>
              <h2 className="font-serif text-xl text-ivory mb-3">5. Custom Service Milestones</h2>
              <p>For custom projects with milestone payments, each milestone payment is non-refundable once the milestone deliverable has been approved by the client. If you are unsatisfied with a milestone deliverable, please communicate your concerns before approving and proceeding to the next milestone.</p>
            </section>
            <section>
              <h2 className="font-serif text-xl text-ivory mb-3">6. Digital Delivery Policy</h2>
              <p>Digital product files are delivered through your secure download area after verified payment. Download links are tied to your purchase record. If you lose access to your downloads, contact us with your order information and we will restore access.</p>
            </section>
            <section>
              <h2 className="font-serif text-xl text-ivory mb-3">7. Payment Pending Orders</h2>
              <p>Orders created with pending payment status (before payment verification) do not grant download access. If a payment fails or is cancelled, the order remains pending and no digital products are delivered. No refund is necessary as no payment was completed.</p>
            </section>
            <section>
              <h2 className="font-serif text-xl text-ivory mb-3">8. How to Request a Refund</h2>
              <p>To request a refund or report a technical issue, contact us through our contact page with your order ID, the product name, and a description of the issue. We will respond within 1-2 business days.</p>
            </section>
            <section>
              <h2 className="font-serif text-xl text-ivory mb-3">9. Chargebacks</h2>
              <p>We encourage you to contact us before initiating a chargeback with your payment provider. We are committed to resolving issues fairly and promptly. Unwarranted chargebacks may result in suspension of your account and access to future purchases.</p>
            </section>
          </div>
        </Reveal>

        <Reveal delay={200}>
          <div className="glass p-6 mt-10 rounded-sm">
            <p className="text-xs text-ivorySoft/30 font-sans font-light leading-relaxed">
              <strong className="text-ivorySoft/50">Note:</strong> This refund policy is a general template. It should be reviewed and customized by a qualified legal professional to ensure compliance with consumer protection laws in your jurisdiction.
            </p>
          </div>
        </Reveal>
      </div>
    </div>
  );
}
