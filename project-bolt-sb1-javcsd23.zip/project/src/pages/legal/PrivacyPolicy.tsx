import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import Reveal from '@/components/Reveal';

export default function PrivacyPolicy() {
  return (
    <div className="pt-32 pb-32 min-h-screen">
      <div className="container-lux max-w-3xl">
        <Reveal>
          <Link to="/" className="link-arrow mb-8 group">
            <ArrowLeft size={14} className="group-hover:-translate-x-1 transition-transform duration-500 ease-luxury" />
            Back to Home
          </Link>
          <p className="eyebrow mb-5"><span className="inline-block w-6 h-px bg-gold/30 align-middle mr-3" />Legal</p>
          <h1 className="heading-display text-4xl md:text-5xl mb-4">Privacy Policy</h1>
          <p className="text-xs text-ivorySoft/30 font-sans font-light mb-10">Last updated: October 2025. This document is a template and should be reviewed by a legal professional for your specific jurisdiction.</p>

        </Reveal>
        <div className="space-y-8 text-sm text-ivorySoft/55 font-sans font-light leading-relaxed">
          <section>
            <h2 className="font-serif text-xl text-ivory mb-3">1. Information We Collect</h2>
            <p>We collect information you provide directly to us, including your name, email address, country, and project requirements when you submit a project inquiry or contact form. When you place an order, we collect billing information including your name, email, address, and country. We do not collect or store payment card details on our servers.</p>
          </section>
          <section>
            <h2 className="font-serif text-xl text-ivory mb-3">2. How We Use Your Information</h2>
            <p>We use your information to respond to inquiries, process orders, deliver digital products, provide customer support, and communicate with you about your projects. We do not sell, rent, or trade your personal information to third parties.</p>
          </section>
          <section>
            <h2 className="font-serif text-xl text-ivory mb-3">3. Cookies and Local Storage</h2>
            <p>Our website uses browser local storage to remember items in your shopping cart and recently placed orders. This data is stored on your device and is not transmitted to our servers. We do not use tracking cookies for advertising purposes.</p>
          </section>
          <section>
            <h2 className="font-serif text-xl text-ivory mb-3">4. Data Security</h2>
            <p>We take reasonable measures to protect your personal information. Payment processing, when activated, will be handled by a certified third-party payment provider. We do not store sensitive payment data on our servers.</p>
          </section>
          <section>
            <h2 className="font-serif text-xl text-ivory mb-3">5. Third-Party Services</h2>
            <p>We may use third-party services for payment processing, email communication, and analytics. These providers have their own privacy policies governing how they handle your data.</p>
          </section>
          <section>
            <h2 className="font-serif text-xl text-ivory mb-3">6. Your Rights</h2>
            <p>You have the right to request access to, correction of, or deletion of your personal information. To exercise these rights, please contact us using the email provided on our contact page.</p>
          </section>
          <section>
            <h2 className="font-serif text-xl text-ivory mb-3">7. Children's Privacy</h2>
            <p>Our services are not directed to individuals under the age of 16. We do not knowingly collect personal information from children.</p>
          </section>
          <section>
            <h2 className="font-serif text-xl text-ivory mb-3">8. Changes to This Policy</h2>
            <p>We may update this privacy policy from time to time. Any changes will be posted on this page with an updated revision date.</p>
          </section>
          <section>
            <h2 className="font-serif text-xl text-ivory mb-3">9. Contact</h2>
            <p>For privacy-related questions, please contact us through our contact page.</p>
          </section>
        </div>

        <Reveal>
        <div className="glass p-6 mt-10 rounded-sm">
          <p className="text-xs text-ivorySoft/30 font-sans font-light leading-relaxed">
            <strong className="text-ivorySoft/60">Note:</strong> This privacy policy is a general template. It should be reviewed and customized by a qualified legal professional to ensure compliance with applicable laws in your jurisdiction, including but not limited to GDPR (EU), CCPA (California), and the Personal Data Protection Bill (Pakistan).
          </p>
        </div>
        </Reveal>
      </div>
    </div>
  );
}
