import { useState } from 'react';
import { ArrowRight, Check } from 'lucide-react';
import { websitePackages, ecommercePackages } from '@/data/content';
import Reveal from '@/components/Reveal';

const countries = ['United States', 'United Kingdom', 'Canada', 'Australia', 'Germany', 'France', 'Italy', 'Spain', 'Netherlands', 'Belgium', 'Switzerland', 'Sweden', 'Norway', 'Denmark', 'United Arab Emirates', 'Saudi Arabia', 'Qatar', 'Pakistan', 'India', 'Singapore', 'Japan', 'Other'];

const services = ['Website Design', 'E-Commerce Development', 'WordPress Development', 'Website Redesign', 'SEO Foundations', 'Digital Product Customization'];
const budgets = ['Under $200 USD', '$200 – $350 USD', '$350 – $500 USD', '$500+ USD', 'Not sure yet'];
const timelines = ['ASAP', '1-2 weeks', '3-4 weeks', '1-2 months', 'Flexible'];

export default function ProjectInquiry() {
  const allPackages = [...websitePackages, ...ecommercePackages].map((p) => p.name);
  const [form, setForm] = useState({
    name: '', email: '', country: '', service: '', package: '', budget: '', requirements: '', referenceUrl: '', timeline: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = 'Name is required';
    if (!form.email.trim()) e.email = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Valid email required';
    if (!form.country) e.country = 'Country is required';
    if (!form.service) e.service = 'Please select a service';
    if (!form.requirements.trim()) e.requirements = 'Please describe your project requirements';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!validate()) return;
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
    }, 1500);
  };

  return (
    <div className="pt-32 pb-32 min-h-screen">
      <div className="container-lux max-w-3xl">
        <Reveal>
          <div className="text-center mb-16">
            <p className="eyebrow mb-5">
              <span className="inline-block w-6 h-px bg-gold/30 align-middle mr-3" />
              Project Inquiry
            </p>
            <h1 className="heading-display text-4xl md:text-5xl lg:text-6xl mb-6">Start Your Project</h1>
            <p className="text-sm text-ivorySoft/45 font-sans font-light leading-relaxed max-w-xl mx-auto">
              Tell us about your project. We'll review your inquiry and respond within 1-2 business days with next steps and a proposed timeline.
            </p>
          </div>
        </Reveal>

        {submitted ? (
          <Reveal delay={100}>
            <div className="glass-elevated p-12 text-center rounded-sm">
              <div className="w-16 h-16 border border-gold/20 rounded-full flex items-center justify-center mx-auto mb-6 glass-gold">
                <Check size={28} strokeWidth={1.5} className="text-gold" />
              </div>
              <h2 className="font-serif text-2xl text-ivory mb-4">Inquiry Received</h2>
              <p className="text-sm text-ivorySoft/45 font-sans font-light leading-relaxed mb-2">
                Thank you, {form.name}. We have received your project inquiry.
              </p>
              <p className="text-sm text-ivorySoft/45 font-sans font-light leading-relaxed mb-8">
                We'll respond to {form.email} within 1-2 business days with next steps and a proposed timeline.
              </p>
              <button
                onClick={() => { setSubmitted(false); setForm({ name: '', email: '', country: '', service: '', package: '', budget: '', requirements: '', referenceUrl: '', timeline: '' }); }}
                className="btn-outline"
              >
                Submit Another Inquiry
              </button>
            </div>
          </Reveal>
        ) : (
          <Reveal delay={100}>
            <form onSubmit={handleSubmit} className="glass-elevated p-10 space-y-5 rounded-sm">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="label-lux" htmlFor="pi-name">Name *</label>
                  <input id="pi-name" type="text" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="input-lux" />
                  {errors.name && <p className="text-xs text-red-400/70 mt-1">{errors.name}</p>}
                </div>
                <div>
                  <label className="label-lux" htmlFor="pi-email">Email *</label>
                  <input id="pi-email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="input-lux" />
                  {errors.email && <p className="text-xs text-red-400/70 mt-1">{errors.email}</p>}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="label-lux" htmlFor="pi-country">Country *</label>
                  <select id="pi-country" value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} className="input-lux">
                    <option value="">Select country</option>
                    {countries.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                  {errors.country && <p className="text-xs text-red-400/70 mt-1">{errors.country}</p>}
                </div>
                <div>
                  <label className="label-lux" htmlFor="pi-service">Desired Service *</label>
                  <select id="pi-service" value={form.service} onChange={(e) => setForm({ ...form, service: e.target.value })} className="input-lux">
                    <option value="">Select service</option>
                    {services.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                  {errors.service && <p className="text-xs text-red-400/70 mt-1">{errors.service}</p>}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="label-lux" htmlFor="pi-package">Selected Package (optional)</label>
                  <select id="pi-package" value={form.package} onChange={(e) => setForm({ ...form, package: e.target.value })} className="input-lux">
                    <option value="">Select package</option>
                    {allPackages.map((p) => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
                <div>
                  <label className="label-lux" htmlFor="pi-budget">Project Budget (optional)</label>
                  <select id="pi-budget" value={form.budget} onChange={(e) => setForm({ ...form, budget: e.target.value })} className="input-lux">
                    <option value="">Select budget range</option>
                    {budgets.map((b) => <option key={b} value={b}>{b}</option>)}
                  </select>
                </div>
              </div>

              <div>
                <label className="label-lux" htmlFor="pi-requirements">Project Requirements *</label>
                <textarea id="pi-requirements" rows={5} value={form.requirements} onChange={(e) => setForm({ ...form, requirements: e.target.value })} className="input-lux resize-none" placeholder="Describe your project, including the type of website or store, key features, and any specific requirements..." />
                {errors.requirements && <p className="text-xs text-red-400/70 mt-1">{errors.requirements}</p>}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="label-lux" htmlFor="pi-reference">Reference URL (optional)</label>
                  <input id="pi-reference" type="url" value={form.referenceUrl} onChange={(e) => setForm({ ...form, referenceUrl: e.target.value })} className="input-lux" placeholder="https://example.com" />
                </div>
                <div>
                  <label className="label-lux" htmlFor="pi-timeline">Preferred Timeline (optional)</label>
                  <select id="pi-timeline" value={form.timeline} onChange={(e) => setForm({ ...form, timeline: e.target.value })} className="input-lux">
                    <option value="">Select timeline</option>
                    {timelines.map((t) => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
              </div>

              <button type="submit" disabled={submitting} className="btn-primary w-full disabled:opacity-50">
                {submitting ? 'Submitting...' : <>Submit Inquiry <ArrowRight size={16} /></>}
              </button>
              <p className="text-xs text-ivorySoft/30 font-sans font-light text-center">
                No obligation. We'll review and respond — you decide whether to proceed.
              </p>
            </form>
          </Reveal>
        )}
      </div>
    </div>
  );
}
