import { Link, useLocation } from 'react-router-dom';
import { Check, Download, ArrowRight, Clock, Info } from 'lucide-react';
import { useEffect, useState } from 'react';
import Reveal from '@/components/Reveal';

interface OrderData {
  orderId: string;
  items: { name: string; price: number; quantity: number; slug: string }[];
  total: number;
  customer: { name: string; email: string };
  status: string;
  date: string;
}

export default function OrderConfirmation() {
  const location = useLocation();
  const [order, setOrder] = useState<OrderData | null>(null);

  useEffect(() => {
    try {
      const stored = localStorage.getItem('nexora-last-order');
      if (stored) setOrder(JSON.parse(stored));
    } catch {
      // ignore
    }
  }, []);

  const orderId = (location.state as { orderId?: string })?.orderId || order?.orderId || 'NX-PENDING';

  return (
    <div className="pt-32 pb-32 min-h-screen">
      <div className="container-lux max-w-2xl">
        <Reveal>
          <div className="text-center mb-16">
            <div className="w-20 h-20 border border-gold/20 rounded-full flex items-center justify-center mx-auto mb-8 glass-gold">
              <Check size={36} strokeWidth={1.5} className="text-gold" />
            </div>
            <p className="eyebrow mb-5">
              <span className="inline-block w-6 h-px bg-gold/30 align-middle mr-3" />
              Order Confirmation
            </p>
            <h1 className="heading-display text-4xl md:text-5xl mb-4">Order Received</h1>
            <p className="text-sm text-ivorySoft/45 font-sans font-light">
              Your order has been created. Order ID: <span className="text-gold font-sans">{orderId}</span>
            </p>
          </div>
        </Reveal>

        <Reveal delay={100}>
          <div className="glass-gold p-6 mb-6 rounded-sm">
            <div className="flex items-start gap-3">
              <Info size={20} strokeWidth={1.5} className="text-gold/60 shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-sans font-light text-ivorySoft/70 mb-1">Payment Pending — Awaiting Activation</p>
                <p className="text-xs text-ivorySoft/40 font-sans font-light leading-relaxed">
                  Your order has been created with pending payment status. Live payment processing is not yet active. Once our payment provider is approved and configured, you will receive an email with instructions to complete payment securely. Digital downloads will be available after verified payment.
                </p>
              </div>
            </div>
          </div>
        </Reveal>

        {order && (
          <Reveal delay={200}>
            <div className="glass p-8 mb-6 rounded-sm">
              <h2 className="font-serif text-xl text-ivory mb-5">Order Details</h2>
              <div className="space-y-3 mb-5">
                {order.items.map((item, i) => (
                  <div key={i} className="flex justify-between text-sm font-sans font-light">
                    <div>
                      <span className="text-ivorySoft/70">{item.name}</span>
                      <span className="text-ivorySoft/30 ml-2">x{item.quantity}</span>
                    </div>
                    <span className="text-gold">${(item.price * item.quantity).toLocaleString()} USD</span>
                  </div>
                ))}
              </div>
              <div className="divider-gold my-3" />
              <div className="flex justify-between">
                <span className="font-serif text-lg text-ivory">Total</span>
                <span className="font-serif text-xl text-gold">${order.total.toLocaleString()} USD</span>
              </div>
              <div className="mt-4 pt-4 border-t border-white/[0.04] text-xs font-sans font-light text-ivorySoft/40 space-y-1">
                <p>Name: {order.customer.name}</p>
                <p>Email: {order.customer.email}</p>
                <p>Date: {new Date(order.date).toLocaleDateString()}</p>
                <p>Status: <span className="text-gold/60 capitalize">{order.status.replace('-', ' ')}</span></p>
              </div>
            </div>
          </Reveal>
        )}

        <Reveal delay={300}>
          <div className="glass p-8 mb-10 rounded-sm">
            <h2 className="font-serif text-xl text-ivory mb-4 flex items-center gap-2">
              <Download size={20} strokeWidth={1.5} className="text-gold/50" /> Digital Downloads
            </h2>
            <p className="text-xs text-ivorySoft/40 font-sans font-light leading-relaxed mb-4">
              Once your payment is verified, your purchased product files will be available for download. You will receive an email notification when your downloads are ready.
            </p>
            <div className="flex items-center gap-2 text-xs text-ivorySoft/30 font-sans font-light">
              <Clock size={14} strokeWidth={1.5} className="text-gold/40" /> Downloads unlock after verified payment.
            </div>
          </div>
        </Reveal>

        <Reveal delay={400}>
          <div className="text-center">
            <Link to="/shop" className="btn-primary">
              Continue Shopping <ArrowRight size={16} />
            </Link>
          </div>
        </Reveal>
      </div>
    </div>
  );
}
