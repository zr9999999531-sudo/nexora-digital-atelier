import { useParams, Link } from 'react-router-dom';
import { ArrowRight, Check, PenTool, Store, Download, Sparkles, Search, Zap, Shield, Code2 } from 'lucide-react';
import { websitePackages, ecommercePackages, faqItems } from '@/data/content';
import { websiteTemplates, ecommerceTemplates } from '@/data/products';
import ProductCard from '@/components/ProductCard';
import SectionHeading from '@/components/SectionHeading';
import Reveal from '@/components/Reveal';

interface LandingPageConfig {
  slug: string;
  eyebrow: string;
  headline: string;
  subheadline: string;
  heroImage: string;
  primaryCta: string;
  primaryCtaLink: string;
  secondaryCta: string;
  secondaryCtaLink: string;
  benefits: string[];
  features: { icon: typeof Zap; title: string; desc: string }[];
  pricingTitle: string;
  showWebsitePackages: boolean;
  showEcommercePackages: boolean;
  showTemplates: boolean;
  templateCategory?: 'website' | 'ecommerce';
  faqCategory: string;
}

const landingPages: Record<string, LandingPageConfig> = {
  'premium-website-design': {
    slug: 'premium-website-design',
    eyebrow: 'Premium Business Website Design',
    headline: 'A Website That Reflects the Quality of Your Business',
    subheadline: 'Custom-designed, professionally built websites that elevate your brand and convert visitors into customers. From $150 USD. Serving clients worldwide.',
    heroImage: 'https://images.pexels.com/photos/1170412/pexels-photo-1170412.jpeg?auto=compress&cs=tinysrgb&h=1080&w=1920',
    primaryCta: 'Start Your Website Project',
    primaryCtaLink: '/project-inquiry',
    secondaryCta: 'View Full Pricing',
    secondaryCtaLink: '/pricing',
    benefits: [
      'Custom design from scratch — no recycled templates',
      'Responsive across mobile, tablet, and desktop',
      'SEO-optimized architecture for search visibility',
      'Fast loading and accessible by default',
      'Clear deliverables with transparent USD pricing',
      '1-2 business day response on all inquiries',
    ],
    features: [
      { icon: PenTool, title: 'Custom Design', desc: 'Every website is designed from scratch to match your brand identity and audience expectations.' },
      { icon: Zap, title: 'Performance-Optimized', desc: 'Clean code, optimized images, and modern frameworks for fast loading on every device.' },
      { icon: Search, title: 'SEO Foundation', desc: 'Semantic HTML, meta tags, and structured data built in from day one — not added later.' },
      { icon: Shield, title: 'Honest Process', desc: 'Transparent pricing, clear deliverables, and no false promises about rankings or results.' },
    ],
    pricingTitle: 'Website Design Packages',
    showWebsitePackages: true,
    showEcommercePackages: false,
    showTemplates: false,
    faqCategory: 'Services',
  },
  'custom-ecommerce-store': {
    slug: 'custom-ecommerce-store',
    eyebrow: 'Custom E-Commerce Store Development',
    headline: 'A Professional Online Store Built to Sell',
    subheadline: 'Complete e-commerce development with product catalog, cart, checkout, and payment integration ready. From $100 USD. Built for international customers.',
    heroImage: 'https://images.pexels.com/photos/6207729/pexels-photo-6207729.jpeg?auto=compress&cs=tinysrgb&h=1080&w=1920',
    primaryCta: 'Start Your Store Project',
    primaryCtaLink: '/project-inquiry',
    secondaryCta: 'View Full Pricing',
    secondaryCtaLink: '/pricing',
    benefits: [
      'Complete online store with cart and checkout',
      'Payment provider integration ready',
      'Product catalog with categories and search',
      'Mobile-optimized shopping experience',
      'Customer accounts and order history (higher tiers)',
      'All prices in USD for worldwide customers',
    ],
    features: [
      { icon: Store, title: 'Full Store Build', desc: 'Product listings, detail pages, cart, checkout, and order confirmation — all built and ready.' },
      { icon: Shield, title: 'Secure Checkout', desc: 'Payment integration prepared for a certified provider. No card data collected on your site.' },
      { icon: Zap, title: 'Conversion-Focused', desc: 'Clear product pages, streamlined checkout, and trust-building design throughout.' },
      { icon: Search, title: 'Discoverable', desc: 'SEO-optimized product pages with structured data for search engine visibility.' },
    ],
    pricingTitle: 'E-Commerce Development Packages',
    showWebsitePackages: false,
    showEcommercePackages: true,
    showTemplates: false,
    faqCategory: 'Services',
  },
  'luxury-website-templates': {
    slug: 'luxury-website-templates',
    eyebrow: 'Luxury Website Templates',
    headline: 'Premium Website Templates, Ready to Launch',
    subheadline: '16 professionally designed website templates across 8 industries. Complete source code, assets, and documentation. Instant download from $150 USD.',
    heroImage: 'https://images.pexels.com/photos/18453934/pexels-photo-18453934.jpeg?auto=compress&cs=tinysrgb&h=1080&w=1920',
    primaryCta: 'Browse Website Templates',
    primaryCtaLink: '/shop/website-templates',
    secondaryCta: 'Start a Custom Project',
    secondaryCtaLink: '/project-inquiry',
    benefits: [
      '16 premium templates across 8 industries',
      'Complete source code and all assets included',
      'Responsive, SEO-friendly, and accessible',
      'Setup guide and documentation included',
      '30 days email support for installation',
      'Single-site commercial license',
    ],
    features: [
      { icon: Download, title: 'Instant Download', desc: 'Get complete source code, assets, and documentation immediately after verified payment.' },
      { icon: Code2, title: 'Modern Technology', desc: 'Built with React 18, TypeScript, and Tailwind CSS — the same stack we use for custom projects.' },
      { icon: Zap, title: 'Fast Setup', desc: 'Extract, install, and customize. Most templates are running in under an hour.' },
      { icon: Shield, title: 'Honest Licensing', desc: 'Single-site commercial license. Use on one live website. Modify for your brand.' },
    ],
    pricingTitle: 'Featured Website Templates',
    showWebsitePackages: false,
    showEcommercePackages: false,
    showTemplates: true,
    templateCategory: 'website',
    faqCategory: 'Products',
  },
  'online-store-templates': {
    slug: 'online-store-templates',
    eyebrow: 'Online Store Templates',
    headline: 'Complete E-Commerce Templates, Ready to Customize',
    subheadline: '8 professional e-commerce templates with cart, checkout, and product management. Full source code included. Instant download from $100 USD.',
    heroImage: 'https://images.pexels.com/photos/7679456/pexels-photo-7679456.jpeg?auto=compress&cs=tinysrgb&h=1080&w=1920',
    primaryCta: 'Browse E-Commerce Templates',
    primaryCtaLink: '/shop/ecommerce-templates',
    secondaryCta: 'Start a Custom Store',
    secondaryCtaLink: '/project-inquiry',
    benefits: [
      '8 e-commerce templates across 6 industries',
      'Cart, checkout, and product catalog built-in',
      'Complete source code and assets included',
      'Payment provider integration ready',
      'Mobile-optimized shopping experience',
      'From $100 USD with instant download',
    ],
    features: [
      { icon: Store, title: 'Store Ready', desc: 'Product listings, detail pages, cart, and checkout flow — all built and ready to customize.' },
      { icon: Download, title: 'Full Source Code', desc: 'Complete React and TypeScript source with all assets, configuration, and documentation.' },
      { icon: Search, title: 'Search & Filter', desc: 'Product search, category filtering, and sorting built into every template.' },
      { icon: Shield, title: 'Secure Foundation', desc: 'Payment integration prepared for a certified provider. Documented setup requirements.' },
    ],
    pricingTitle: 'Featured E-Commerce Templates',
    showWebsitePackages: false,
    showEcommercePackages: false,
    showTemplates: true,
    templateCategory: 'ecommerce',
    faqCategory: 'Products',
  },
  'professional-website-redesign': {
    slug: 'professional-website-redesign',
    eyebrow: 'Professional Website Redesign',
    headline: 'Transform Your Existing Website Into a Premium Experience',
    subheadline: 'We redesign and rebuild your current website with modern technology, improved performance, and refined design. Preserve your content, elevate your presence.',
    heroImage: 'https://images.pexels.com/photos/31949770/pexels-photo-31949770.jpeg?auto=compress&cs=tinysrgb&h=1080&w=1920',
    primaryCta: 'Start Your Redesign',
    primaryCtaLink: '/project-inquiry',
    secondaryCta: 'View Website Packages',
    secondaryCtaLink: '/pricing',
    benefits: [
      'Complete design audit and strategy',
      'Content migration from your current site',
      'Modern framework rebuild with clean code',
      'Performance improvement and SEO preservation',
      'Redirect management to protect search rankings',
      'Responsive design across all devices',
    ],
    features: [
      { icon: Sparkles, title: 'Design Audit', desc: 'We review your current website and identify what works, what does not, and what to improve.' },
      { icon: PenTool, title: 'Fresh Design', desc: 'A new visual identity that respects your brand while elevating the user experience.' },
      { icon: Zap, title: 'Modern Tech', desc: 'Rebuilt with React, TypeScript, and Tailwind CSS for speed, maintainability, and scalability.' },
      { icon: Shield, title: 'SEO Protected', desc: 'Redirects, meta tags, and structured data managed carefully to preserve your search presence.' },
    ],
    pricingTitle: 'Redesign Packages',
    showWebsitePackages: true,
    showEcommercePackages: false,
    showTemplates: false,
    faqCategory: 'Services',
  },
};

export default function LandingPage() {
  const { slug } = useParams<{ slug: string }>();
  const config = landingPages[slug || ''] || landingPages['premium-website-design'];

  const relevantFaqs = faqItems.filter((f) => f.category === config.faqCategory).slice(0, 4);
  const templates = config.templateCategory === 'website'
    ? websiteTemplates.filter((p) => p.featured).slice(0, 4)
    : config.templateCategory === 'ecommerce'
    ? ecommerceTemplates.slice(0, 4)
    : [];
  const packages = config.showWebsitePackages
    ? websitePackages
    : config.showEcommercePackages
    ? ecommercePackages
    : [];

  return (
    <div className="pt-20">
      {/* Hero */}
      <section className="relative min-h-[70vh] flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <img src={config.heroImage} alt="" className="w-full h-full object-cover opacity-15" />
          <div className="absolute inset-0 bg-gradient-to-b from-obsidian/80 via-obsidian/90 to-obsidian" />
          <div className="absolute inset-0 bg-gradient-to-r from-obsidian via-transparent to-obsidian/50" />
        </div>
        <div className="container-lux-full relative z-10 py-20">
          <Reveal>
            <div className="max-w-3xl">
              <p className="eyebrow mb-6">
                <span className="inline-block w-6 h-px bg-gold/30 align-middle mr-3" />
                {config.eyebrow}
              </p>
              <h1 className="heading-display text-4xl md:text-5xl lg:text-6xl mb-6 leading-[1.1]">
                {config.headline}
              </h1>
              <p className="text-lg text-ivorySoft/50 font-sans font-light leading-relaxed mb-10 max-w-xl">
                {config.subheadline}
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to={config.primaryCtaLink} className="btn-primary">
                  {config.primaryCta} <ArrowRight size={16} />
                </Link>
                <Link to={config.secondaryCtaLink} className="btn-outline">
                  {config.secondaryCta}
                </Link>
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-32 bg-obsidian">
        <div className="container-lux max-w-4xl">
          <Reveal>
            <SectionHeading eyebrow="Why Choose This Option" title="Key Benefits" />
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-white/[0.04] mt-12">
            {config.benefits.map((b, i) => (
              <Reveal key={i} delay={(i % 2) * 80}>
                <div className="bg-obsidian p-6 flex items-start gap-3 hover:bg-white/[0.01] transition-all duration-700 ease-luxury">
                  <Check size={16} strokeWidth={1.5} className="text-gold/50 mt-0.5 shrink-0" />
                  <span className="text-sm font-sans font-light text-ivorySoft/65">{b}</span>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-32 bg-charcoal-dark">
        <div className="container-lux-full">
          <Reveal>
            <SectionHeading eyebrow="What's Included" title="Features" center />
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-white/[0.04] mt-16">
            {config.features.map((f, i) => (
              <Reveal key={f.title} delay={i * 100}>
                <div className="bg-charcoal-dark p-10 h-full hover:bg-white/[0.01] transition-all duration-700 ease-luxury group">
                  <f.icon size={28} strokeWidth={1.5} className="text-gold/50 mb-6 group-hover:text-gold/70 transition-colors duration-700" />
                  <h3 className="font-serif text-lg text-ivory mb-3">{f.title}</h3>
                  <p className="text-xs text-ivorySoft/40 font-sans font-light leading-relaxed">{f.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing or Templates */}
      {packages.length > 0 && (
        <section className="py-32 bg-obsidian">
          <div className="container-lux-full">
            <Reveal>
              <SectionHeading
                eyebrow="Transparent Pricing"
                title={config.pricingTitle}
                subtitle="All prices in USD. Additional costs for domains, hosting, and third-party services are not included."
                center
              />
            </Reveal>
            <div className={`grid gap-4 mt-16 ${packages.length <= 5 ? 'md:grid-cols-2 lg:grid-cols-5' : 'md:grid-cols-2 lg:grid-cols-4'}`}>
              {packages.map((pkg, i) => (
                <Reveal key={pkg.id} delay={i * 80}>
                  <div className={`surface-card p-8 flex flex-col hover:border-gold/20 transition-all duration-700 ease-luxury h-full ${pkg.popular ? '!border-gold/25 relative glow-gold' : ''}`}>
                    {pkg.popular && (
                      <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gold text-obsidian text-[9px] uppercase tracking-wider-2 font-sans font-medium px-3 py-1">
                        Popular
                      </span>
                    )}
                    <h3 className="font-serif text-base text-ivory mb-2">{pkg.name}</h3>
                    <p className="font-serif text-2xl text-gold mb-4">{pkg.priceLabel}</p>
                    <p className="text-xs text-ivorySoft/40 font-sans font-light leading-relaxed mb-6 flex-1">{pkg.description}</p>
                    <Link to="/project-inquiry" className="btn-outline w-full !py-3 !text-[10px]">
                      Get Started
                    </Link>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </section>
      )}

      {config.showTemplates && templates.length > 0 && (
        <section className="py-32 bg-obsidian">
          <div className="container-lux-full">
            <Reveal>
              <SectionHeading
                eyebrow="Available Templates"
                title={config.pricingTitle}
                center
              />
            </Reveal>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-16 mb-12">
              {templates.map((product, i) => (
                <Reveal key={product.id} delay={i * 100}>
                  <ProductCard product={product} />
                </Reveal>
              ))}
            </div>
            <Reveal delay={200}>
              <div className="text-center">
                <Link to={config.templateCategory === 'website' ? '/shop/website-templates' : '/shop/ecommerce-templates'} className="btn-primary">
                  View All Templates <ArrowRight size={16} />
                </Link>
              </div>
            </Reveal>
          </div>
        </section>
      )}

      {/* FAQ */}
      <section className="py-32 bg-charcoal-dark">
        <div className="container-lux max-w-3xl">
          <Reveal>
            <SectionHeading eyebrow="Questions" title="Frequently Asked" center />
          </Reveal>
          <div className="space-y-px bg-white/[0.04] mt-12">
            {relevantFaqs.map((faq, i) => (
              <Reveal key={i} delay={i * 60}>
                <details className="group bg-charcoal-dark cursor-pointer">
                  <summary className="flex items-center justify-between list-none p-6 lg:p-8">
                    <span className="font-serif text-base text-ivory pr-4">{faq.question}</span>
                    <span className="text-gold/50 text-2xl font-light group-open:rotate-45 transition-transform duration-500 ease-luxury shrink-0">+</span>
                  </summary>
                  <p className="px-6 lg:px-8 pb-6 lg:pb-8 text-sm text-ivorySoft/45 font-sans font-light leading-relaxed">{faq.answer}</p>
                </details>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-40 bg-charcoal border-t border-white/[0.04] relative overflow-hidden">
        <div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] rounded-full opacity-[0.04] blur-[100px] pointer-events-none"
          style={{ background: 'radial-gradient(circle, #c9a96e 0%, transparent 70%)' }}
        />
        <div className="container-lux text-center relative">
          <Reveal>
            <p className="eyebrow mb-6">Take the Next Step</p>
            <h2 className="heading-display text-4xl md:text-5xl mb-8">
              Ready to <span className="text-gradient-gold italic font-normal">Get Started?</span>
            </h2>
            <p className="text-sm text-ivorySoft/45 font-sans font-light leading-relaxed max-w-xl mx-auto mb-12">
              Submit a project inquiry and we'll respond within 1-2 business days with next steps and a proposed timeline. No obligation.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to={config.primaryCtaLink} className="btn-primary">
                {config.primaryCta} <ArrowRight size={16} />
              </Link>
              <Link to="/contact" className="btn-outline">
                Contact Us
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
