import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { ArrowLeft, ArrowRight, Lock, Info } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import Reveal from '@/components/Reveal';

interface CheckoutForm {
  name: string;
  email: string;
  country: string;
  company: string;
  address: string;
  city: string;
  zip: string;
}

const countries = ['United States', 'United Kingdom', 'Canada', 'Australia', 'Germany', 'France', 'Italy', 'Spain', 'Netherlands', 'Belgium', 'Switzerland', 'Sweden', 'Norway', 'Denmark', 'United Arab Emirates', 'Saudi Arabia', 'Qatar', 'Pakistan', 'India', 'Singapore', 'Japan', 'Other'];

export default function Checkout() {
  const { items, subtotal, clearCart } = useCart();
  const navigate = useNavigate();
  const [form, setForm] = useState<CheckoutForm>({
    name: '', email: '', country: '', company: '', address: '', city: '', zip: '',
  });
  const [errors, setErrors] = useState<Partial<CheckoutForm>>({});
  const [submitting, setSubmitting] = useState(false);

  if (items.length === 0) {
    return (
      <div className="pt-32 pb-24 min-h-screen flex items-center">
        <div className="container-lux max-w-2xl text-center">
          <h1 className="heading-display text-4xl mb-6">Your Cart is Empty</h1>
          <p className="text-sm text-ivorySoft/45 font-sans font-light mb-10">Add products to your cart before checking out.</p>
          <Link to="/shop" className="btn-primary">Shop Products</Link>
        </div>
      </div>
    );
  }

  const validate = (): boolean => {
    const e: Partial<CheckoutForm> = {};
    if (!form.name.trim()) e.name = 'Name is required';
    if (!form.email.trim()) e.email = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Valid email is required';
    if (!form.country) e.country = 'Country is required';
    if (!form.address.trim()) e.address = 'Address is required';
    if (!form.city.trim()) e.city = 'City is required';
    if (!form.zip.trim()) e.zip = 'ZIP/Postal code is required';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!validate()) return;
    setSubmitting(true);
    setTimeout(() => {
      const orderId = `NX-${Date.now().toString(36).toUpperCase()}`;
      try {
        localStorage.setItem('nexora-last-order', JSON.stringify({
          orderId,
          items: items.map((i) => ({ name: i.product.name, price: i.product.price, quantity: i.quantity, slug: i.product.slug })),
          total: subtotal,
          customer: form,
          status: 'pending-payment',
          date: new Date().toISOString(),
        }));
      } catch {
        // ignore
      }
      clearCart();
      navigate('/order-confirmation', { state: { orderId, status: 'pending-payment' } });
    }, 1500);
  };

  return (
    <div className="pt-32 pb-32 min-h-screen">
      <div className="container-lux-full">
        <Reveal>
          <Link to="/cart" className="link-arrow mb-4 group">
            <ArrowLeft size={14} className="group-hover:-translate-x-1 transition-transform duration-500 ease-luxury" />
            Back to Cart
          </Link>
          <h1 className="heading-display text-4xl md:text-5xl mb-10">Checkout</h1>
        </Reveal>

        <Reveal delay={100}>
          <div className="glass-gold p-6 mb-8 rounded-sm">
            <div className="flex items-start gap-3">
              <Info size={20} strokeWidth={1.5} className="text-gold/60 shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-sans font-light text-ivorySoft/70 mb-1">Payment Integration Pending Setup</p>
                <p className="text-xs text-ivorySoft/40 font-sans font-light leading-relaxed">
                  Live payment processing is not yet active. Your order will be created as pending. Once our payment provider is approved and configured, you will be able to complete payment securely. No card details are collected on this page.
                </p>
              </div>
            </div>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-8">
          <Reveal>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="glass p-8 rounded-sm">
                <h2 className="font-serif text-xl text-ivory mb-6">Billing Information</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="label-lux" htmlFor="name">Full Name *</label>
                    <input id="name" type="text" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="input-lux" />
                    {errors.name && <p className="text-xs text-red-400/70 mt-1">{errors.name}</p>}
                  </div>
                  <div>
                    <label className="label-lux" htmlFor="email">Email *</label>
                    <input id="email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="input-lux" />
                    {errors.email && <p className="text-xs text-red-400/70 mt-1">{errors.email}</p>}
                  </div>
                  <div>
                    <label className="label-lux" htmlFor="country">Country *</label>
                    <select id="country" value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} className="input-lux">
                      <option value="">Select country</option>
                      {countries.map((c) => <option key={c} value={c}>{c}</option>)}
                    </select>
                    {errors.country && <p className="text-xs text-red-400/70 mt-1">{errors.country}</p>}
                  </div>
                  <div>
                    <label className="label-lux" htmlFor="company">Company (optional)</label>
                    <input id="company" type="text" value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} className="input-lux" />
                  </div>
                  <div className="md:col-span-2">
                    <label className="label-lux" htmlFor="address">Address *</label>
                    <input id="address" type="text" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className="input-lux" />
                    {errors.address && <p className="text-xs text-red-400/70 mt-1">{errors.address}</p>}
                  </div>
                  <div>
                    <label className="label-lux" htmlFor="city">City *</label>
                    <input id="city" type="text" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="input-lux" />
                    {errors.city && <p className="text-xs text-red-400/70 mt-1">{errors.city}</p>}
                  </div>
                  <div>
                    <label className="label-lux" htmlFor="zip">ZIP / Postal Code *</label>
                    <input id="zip" type="text" value={form.zip} onChange={(e) => setForm({ ...form, zip: e.target.value })} className="input-lux" />
                    {errors.zip && <p className="text-xs text-red-400/70 mt-1">{errors.zip}</p>}
                  </div>
                </div>
              </div>
              <button type="submit" disabled={submitting} className="btn-primary w-full disabled:opacity-50">
                {submitting ? 'Processing...' : <>Create Order <ArrowRight size={16} /></>}
              </button>
            </form>
          </Reveal>

          <Reveal delay={100}>
            <div className="glass-elevated p-8 h-fit sticky top-28 rounded-sm">
              <h2 className="font-serif text-xl text-ivory mb-6">Order Summary</h2>
              <div className="space-y-3 mb-6 max-h-64 overflow-y-auto">
                {items.map((item) => (
                  <div key={item.product.id} className="flex gap-3 text-xs font-sans font-light">
                    <img src={item.product.image} alt={item.product.name} className="w-12 h-12 object-cover shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-ivorySoft/70 truncate">{item.product.name}</p>
                      <p className="text-ivorySoft/30">Qty: {item.quantity}</p>
                    </div>
                    <span className="text-gold">${(item.product.price * item.quantity).toLocaleString()}</span>
                  </div>
                ))}
              </div>
              <div className="divider-gold my-3" />
              <div className="flex justify-between mb-2">
                <span className="text-sm font-sans font-light text-ivorySoft/50">Subtotal</span>
                <span className="text-sm font-sans font-light text-ivory">${subtotal.toLocaleString()} USD</span>
              </div>
              <div className="flex justify-between mb-4">
                <span className="text-sm font-sans font-light text-ivorySoft/50">Taxes</span>
                <span className="text-sm font-sans font-light text-ivorySoft/30">Pending</span>
              </div>
              <div className="flex justify-between">
                <span className="font-serif text-lg text-ivory">Total</span>
                <span className="font-serif text-xl text-gold">{subtotal.toLocaleString()} USD</span>
              </div>
              <div className="mt-6 flex items-center gap-2 text-xs text-ivorySoft/30 font-sans font-light">
                <Lock size={12} strokeWidth={1.5} /> All prices in USD. Secure checkout.
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </div>
  );
}
