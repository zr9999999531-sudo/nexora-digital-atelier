import { useState } from 'react';
import { Mail, MapPin, ArrowRight, Check } from 'lucide-react';
import { siteConfig } from '@/data/siteConfig';
import Reveal from '@/components/Reveal';

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = 'Name is required';
    if (!form.email.trim()) e.email = 'Email is required';
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Valid email required';
    if (!form.subject.trim()) e.subject = 'Subject is required';
    if (!form.message.trim()) e.message = 'Message is required';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!validate()) return;
    setSubmitting(true);
    setTimeout(() => {
      setSubmitting(false);
      setSubmitted(true);
      setForm({ name: '', email: '', subject: '', message: '' });
    }, 1500);
  };

  return (
    <div className="pt-32 pb-32 min-h-screen">
      <div className="container-lux-full">
        <Reveal>
          <div className="text-center mb-20">
            <p className="eyebrow mb-5">
              <span className="inline-block w-6 h-px bg-gold/30 align-middle mr-3" />
              Get in Touch
            </p>
            <h1 className="heading-display text-4xl md:text-5xl lg:text-6xl mb-6">Contact NEXORA</h1>
            <p className="text-sm text-ivorySoft/45 font-sans font-light max-w-2xl mx-auto leading-relaxed">
              Have a question or want to discuss a project? Send us a message and we'll respond within 1-2 business days.
            </p>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-8">
          <Reveal delay={100}>
            <div className="glass-elevated p-10 rounded-sm">
              {submitted ? (
                <div className="text-center py-16">
                  <div className="w-16 h-16 border border-gold/20 rounded-full flex items-center justify-center mx-auto mb-6 glass-gold">
                    <Check size={28} strokeWidth={1.5} className="text-gold" />
                  </div>
                  <h2 className="font-serif text-2xl text-ivory mb-3">Message Sent</h2>
                  <p className="text-sm text-ivorySoft/45 font-sans font-light mb-8">
                    Thank you for reaching out. We'll respond within 1-2 business days.
                  </p>
                  <button onClick={() => setSubmitted(false)} className="btn-outline">
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit}>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <label className="label-lux" htmlFor="c-name">Name *</label>
                      <input id="c-name" type="text" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="input-lux" />
                      {errors.name && <p className="text-xs text-red-400/70 mt-1">{errors.name}</p>}
                    </div>
                    <div>
                      <label className="label-lux" htmlFor="c-email">Email *</label>
                      <input id="c-email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="input-lux" />
                      {errors.email && <p className="text-xs text-red-400/70 mt-1">{errors.email}</p>}
                    </div>
                  </div>
                  <div className="mb-4">
                    <label className="label-lux" htmlFor="c-subject">Subject *</label>
                    <input id="c-subject" type="text" value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} className="input-lux" />
                    {errors.subject && <p className="text-xs text-red-400/70 mt-1">{errors.subject}</p>}
                  </div>
                  <div className="mb-8">
                    <label className="label-lux" htmlFor="c-message">Message *</label>
                    <textarea id="c-message" rows={6} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} className="input-lux resize-none" />
                    {errors.message && <p className="text-xs text-red-400/70 mt-1">{errors.message}</p>}
                  </div>
                  <button type="submit" disabled={submitting} className="btn-primary w-full disabled:opacity-50">
                    {submitting ? 'Sending...' : <>Send Message <ArrowRight size={16} /></>}
                  </button>
                </form>
              )}
            </div>
          </Reveal>

          <Reveal delay={200}>
            <div className="space-y-6">
              <div className="glass p-7 rounded-sm">
                <h3 className="font-serif text-lg text-ivory mb-6">Contact Information</h3>
                <div className="space-y-5">
                  {siteConfig.email && (
                    <div className="flex items-start gap-3">
                      <Mail size={16} strokeWidth={1.5} className="text-gold/50 mt-0.5 shrink-0" />
                      <div>
                        <p className="text-[10px] uppercase tracking-wider-2 text-ivorySoft/30 font-sans font-light">Email</p>
                        <a href={`mailto:${siteConfig.email}`} className="text-sm text-ivorySoft/70 hover:text-gold transition-colors duration-500 ease-luxury">{siteConfig.email}</a>
                      </div>
                    </div>
                  )}
                  <div className="flex items-start gap-3">
                    <MapPin size={16} strokeWidth={1.5} className="text-gold/50 mt-0.5 shrink-0" />
                    <div>
                      <p className="text-[10px] uppercase tracking-wider-2 text-ivorySoft/30 font-sans font-light">Location</p>
                      <p className="text-sm text-ivorySoft/70 font-sans font-light">{siteConfig.address}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="glass p-7 rounded-sm">
                <h3 className="font-serif text-lg text-ivory mb-3">Response Time</h3>
                <p className="text-xs text-ivorySoft/45 font-sans font-light leading-relaxed">
                  We respond to all inquiries within 1-2 business days. For project-specific discussions, please use our project inquiry form for a more detailed response.
                </p>
              </div>

              <div className="glass p-7 rounded-sm">
                <h3 className="font-serif text-lg text-ivory mb-4">Business Hours</h3>
                <div className="text-xs font-sans font-light text-ivorySoft/45 space-y-2">
                  <p>Monday – Friday: 9:00 AM – 6:00 PM PKT</p>
                  <p>Saturday: 10:00 AM – 2:00 PM PKT</p>
                  <p>Sunday: Closed</p>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </div>
  );
}
