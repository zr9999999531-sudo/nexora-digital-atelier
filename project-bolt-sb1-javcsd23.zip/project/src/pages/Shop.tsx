import { useState, useMemo, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import { allProducts } from '@/data/products';
import ProductCard from '@/components/ProductCard';
import Reveal from '@/components/Reveal';
import type { ProductCategory } from '@/types';

type SortOption = 'featured' | 'price-low' | 'price-high' | 'name';

export default function Shop() {
  const { category } = useParams<{ category?: string }>();
  const [search, setSearch] = useState('');
  const [priceRange, setPriceRange] = useState<'all' | '0-200' | '200-350' | '350-500'>('all');
  const [sort, setSort] = useState<SortOption>('featured');
  const [showFilters, setShowFilters] = useState(false);

  const activeCategory: ProductCategory | 'all' = category === 'website-templates'
    ? 'website'
    : category === 'ecommerce-templates'
    ? 'ecommerce'
    : 'all';

  useEffect(() => {
    setSearch('');
    setPriceRange('all');
  }, [category]);

  const filtered = useMemo(() => {
    let products = [...allProducts];
    if (activeCategory !== 'all') {
      products = products.filter((p) => p.category === activeCategory);
    }
    if (search) {
      const q = search.toLowerCase();
      products = products.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.industry.toLowerCase().includes(q) ||
          p.shortDescription.toLowerCase().includes(q)
      );
    }
    if (priceRange !== 'all') {
      const [min, max] = priceRange.split('-').map(Number);
      products = products.filter((p) => p.price >= min && p.price <= max);
    }
    switch (sort) {
      case 'price-low':
        products.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        products.sort((a, b) => b.price - a.price);
        break;
      case 'name':
        products.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'featured':
      default:
        products.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
    }
    return products;
  }, [activeCategory, search, priceRange, sort]);

  const pageTitle = activeCategory === 'website'
    ? 'Website Templates'
    : activeCategory === 'ecommerce'
    ? 'E-Commerce Templates'
    : 'Digital Products';

  const productCount = filtered.length;

  return (
    <div className="pt-32 pb-32 min-h-screen">
      <div className="container-lux-full">
        {/* Header */}
        <Reveal>
          <div className="text-center mb-16">
            <p className="eyebrow mb-5">
              <span className="inline-block w-6 h-px bg-gold/30 align-middle mr-3" />
              NEXORA Shop
            </p>
            <h1 className="heading-display text-4xl md:text-5xl lg:text-6xl mb-6">{pageTitle}</h1>
            <p className="text-sm text-ivorySoft/45 font-sans font-light max-w-2xl mx-auto leading-relaxed">
              {activeCategory === 'website' && '16 premium website templates across 8 industries, from $150 to $500 USD.'}
              {activeCategory === 'ecommerce' && '8 complete e-commerce templates across 6 industries, from $100 to $250 USD.'}
              {activeCategory === 'all' && '24 premium digital products — website and e-commerce templates with complete source code, assets, and documentation.'}
            </p>
          </div>
        </Reveal>

        {/* Category tabs + sort */}
        <Reveal delay={100}>
          <div className="flex flex-wrap items-center justify-between gap-4 mb-10">
            <div className="flex items-center gap-2 flex-wrap">
              <Link to="/shop" className={`tag-lux transition-all duration-500 ease-luxury ${activeCategory === 'all' ? '!bg-gold/10 !border-gold/40' : 'hover:!border-gold/25'}`}>All</Link>
              <Link to="/shop/website-templates" className={`tag-lux transition-all duration-500 ease-luxury ${activeCategory === 'website' ? '!bg-gold/10 !border-gold/40' : 'hover:!border-gold/25'}`}>Website</Link>
              <Link to="/shop/ecommerce-templates" className={`tag-lux transition-all duration-500 ease-luxury ${activeCategory === 'ecommerce' ? '!bg-gold/10 !border-gold/40' : 'hover:!border-gold/25'}`}>E-Commerce</Link>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="inline-flex items-center gap-2 text-[11px] uppercase tracking-wider-2 text-ivorySoft/60 hover:text-gold transition-colors duration-500 ease-luxury md:hidden font-sans font-light"
              >
                <SlidersHorizontal size={14} strokeWidth={1.5} /> Filters
              </button>
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value as SortOption)}
                className="bg-white/[0.02] backdrop-blur-sm border border-white/[0.08] px-3 py-2 text-[11px] font-sans font-light text-ivory focus:border-gold/40 focus:outline-none transition-all duration-500 ease-luxury"
              >
                <option value="featured">Featured</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="name">Name: A to Z</option>
              </select>
            </div>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 lg:grid-cols-[240px_1fr] gap-8">
          {/* Sidebar */}
          <aside className={`${showFilters ? 'block' : 'hidden'} md:block`}>
            <div className="glass p-6 sticky top-28 rounded-sm">
              <div className="flex items-center justify-between mb-6">
                <h3 className="eyebrow">Filters</h3>
                <button onClick={() => setShowFilters(false)} className="md:hidden text-ivorySoft/60 hover:text-gold transition-colors"><X size={16} /></button>
              </div>
              <div className="mb-6">
                <label className="label-lux">Search</label>
                <div className="relative">
                  <Search size={14} strokeWidth={1.5} className="absolute left-3 top-1/2 -translate-y-1/2 text-ivorySoft/30" />
                  <input
                    type="text"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search..."
                    className="input-lux !pl-9 !py-2.5"
                  />
                </div>
              </div>
              <div className="mb-6">
                <label className="label-lux">Price Range (USD)</label>
                <div className="space-y-2">
                  {[
                    { value: 'all', label: 'All Prices' },
                    { value: '0-200', label: '$100 – $200' },
                    { value: '200-350', label: '$200 – $350' },
                    { value: '350-500', label: '$350 – $500' },
                  ].map((opt) => (
                    <label key={opt.value} className="flex items-center gap-2 text-sm font-sans font-light text-ivorySoft/60 cursor-pointer hover:text-gold transition-colors duration-500">
                      <input
                        type="radio"
                        name="price"
                        value={opt.value}
                        checked={priceRange === opt.value}
                        onChange={(e) => setPriceRange(e.target.value as typeof priceRange)}
                        className="accent-gold"
                      />
                      {opt.label}
                    </label>
                  ))}
                </div>
              </div>
              <p className="text-[11px] text-ivorySoft/30 font-sans font-light">{productCount} product{productCount !== 1 ? 's' : ''}</p>
            </div>
          </aside>

          {/* Products grid */}
          <div>
            {filtered.length === 0 ? (
              <div className="glass p-20 text-center rounded-sm">
                <p className="text-ivorySoft/40 font-sans font-light text-sm mb-6">No products match your filters.</p>
                <button
                  onClick={() => { setSearch(''); setPriceRange('all'); }}
                  className="btn-outline"
                >
                  Clear Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filtered.map((product, i) => (
                  <Reveal key={product.id} delay={(i % 3) * 100}>
                    <ProductCard product={product} />
                  </Reveal>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
