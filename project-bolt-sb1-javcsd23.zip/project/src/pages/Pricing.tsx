import { Link } from 'react-router-dom';
import { Check, ArrowRight } from 'lucide-react';
import { websitePackages, ecommercePackages } from '@/data/content';
import SectionHeading from '@/components/SectionHeading';
import Reveal from '@/components/Reveal';

export default function Pricing() {
  return (
    <div className="pt-32 pb-32 min-h-screen">
      <div className="container-lux-full">
        <Reveal>
          <div className="text-center mb-20">
            <p className="eyebrow mb-5">
              <span className="inline-block w-6 h-px bg-gold/30 align-middle mr-3" />
              Transparent Pricing
            </p>
            <h1 className="heading-display text-4xl md:text-5xl lg:text-6xl mb-6">Pricing & Packages</h1>
            <p className="text-sm text-ivorySoft/45 font-sans font-light max-w-2xl mx-auto leading-relaxed">
              All prices in USD for clients worldwide. No hidden fees. Additional costs for domains, hosting, and third-party services are clearly noted.
            </p>
          </div>
        </Reveal>

        {/* Website Packages */}
        <Reveal>
          <section className="mb-24">
            <SectionHeading
              eyebrow="Custom Development"
              title="Website Design Packages"
              subtitle="From a single-page starter site to a comprehensive signature build — choose the package that fits your needs."
              center
            />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-16">
              {websitePackages.map((pkg, i) => (
                <Reveal key={pkg.id} delay={i * 80}>
                  <div className={`surface-card p-8 flex flex-col hover:border-gold/20 transition-all duration-700 ease-luxury h-full ${pkg.popular ? '!border-gold/25 relative glow-gold' : ''}`}>
                    {pkg.popular && (
                      <span className="absolute -top-px left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold to-transparent" />
                    )}
                    {pkg.popular && (
                      <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gold text-obsidian text-[9px] uppercase tracking-wider-2 font-sans font-medium px-3 py-1">
                        Recommended
                      </span>
                    )}
                    <h3 className="font-serif text-lg text-ivory mb-2">{pkg.name}</h3>
                    <p className="font-serif text-3xl text-gold mb-4">{pkg.priceLabel}</p>
                    <p className="text-xs text-ivorySoft/40 font-sans font-light leading-relaxed mb-6">{pkg.description}</p>
                    <ul className="space-y-2 mb-8 flex-1">
                      {pkg.deliverables.map((d, i) => (
                        <li key={i} className="flex items-start gap-2 text-[11px] font-sans font-light text-ivorySoft/60">
                          <Check size={11} strokeWidth={1.5} className="text-gold/50 mt-0.5 shrink-0" /> {d}
                        </li>
                      ))}
                    </ul>
                    <Link to="/project-inquiry" className="btn-outline w-full !py-3 !text-[10px]">
                      Get Started
                    </Link>
                  </div>
                </Reveal>
              ))}
            </div>
          </section>
        </Reveal>

        {/* E-Commerce Packages */}
        <Reveal>
          <section className="mb-24">
            <SectionHeading
              eyebrow="Online Stores"
              title="E-Commerce Packages"
              subtitle="From a mini store to a full-featured e-commerce platform with accounts, subscriptions, and digital downloads."
              center
            />
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mt-16">
              {ecommercePackages.map((pkg, i) => (
                <Reveal key={pkg.id} delay={i * 80}>
                  <div className={`surface-card p-8 flex flex-col hover:border-gold/20 transition-all duration-700 ease-luxury h-full ${pkg.popular ? '!border-gold/25 relative glow-gold' : ''}`}>
                    {pkg.popular && (
                      <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gold text-obsidian text-[9px] uppercase tracking-wider-2 font-sans font-medium px-3 py-1">
                        Popular
                      </span>
                    )}
                    <h3 className="font-serif text-base text-ivory mb-2">{pkg.name}</h3>
                    <p className="font-serif text-2xl text-gold mb-4">{pkg.priceLabel}</p>
                    <p className="text-xs text-ivorySoft/40 font-sans font-light leading-relaxed mb-6">{pkg.description}</p>
                    <ul className="space-y-2 mb-8 flex-1">
                      {pkg.deliverables.map((d, i) => (
                        <li key={i} className="flex items-start gap-2 text-[11px] font-sans font-light text-ivorySoft/60">
                          <Check size={11} strokeWidth={1.5} className="text-gold/50 mt-0.5 shrink-0" /> {d}
                        </li>
                      ))}
                    </ul>
                    <Link to="/project-inquiry" className="btn-outline w-full !py-3 !text-[10px]">
                      Get Started
                    </Link>
                  </div>
                </Reveal>
              ))}
            </div>
          </section>
        </Reveal>

        {/* Digital Products Note */}
        <Reveal>
          <section className="glass-elevated p-10 mb-12 rounded-sm">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <SectionHeading
                  eyebrow="Ready-Made Templates"
                  title="Prefer a Faster Option?"
                  subtitle="Our digital product shop offers 24 ready-made templates from $100 to $500 USD. Instant download after purchase."
                />
                <Link to="/shop" className="btn-primary mt-8">
                  Browse Digital Products <ArrowRight size={16} />
                </Link>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="glass p-8 text-center rounded-sm group hover:border-gold/20 transition-all duration-700 ease-luxury">
                  <p className="font-serif text-4xl text-gold mb-2">16</p>
                  <p className="text-[10px] uppercase tracking-wider-2 text-ivorySoft/40 font-sans font-light">Website Templates</p>
                </div>
                <div className="glass p-8 text-center rounded-sm group hover:border-gold/20 transition-all duration-700 ease-luxury">
                  <p className="font-serif text-4xl text-gold mb-2">8</p>
                  <p className="text-[10px] uppercase tracking-wider-2 text-ivorySoft/40 font-sans font-light">E-Commerce Templates</p>
                </div>
              </div>
            </div>
          </section>
        </Reveal>

        {/* Exclusions */}
        <Reveal>
          <div className="glass p-8 rounded-sm">
            <h3 className="font-serif text-xl text-ivory mb-6">What's Not Included</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm font-sans font-light text-ivorySoft/45">
              <ul className="space-y-2">
                <li className="flex items-center gap-2"><span className="w-1 h-1 bg-gold/30 rounded-full shrink-0" /> Domain registration fees</li>
                <li className="flex items-center gap-2"><span className="w-1 h-1 bg-gold/30 rounded-full shrink-0" /> Web hosting subscriptions</li>
                <li className="flex items-center gap-2"><span className="w-1 h-1 bg-gold/30 rounded-full shrink-0" /> Premium plugins or themes</li>
                <li className="flex items-center gap-2"><span className="w-1 h-1 bg-gold/30 rounded-full shrink-0" /> Payment provider transaction fees</li>
              </ul>
              <ul className="space-y-2">
                <li className="flex items-center gap-2"><span className="w-1 h-1 bg-gold/30 rounded-full shrink-0" /> Third-party service subscriptions</li>
                <li className="flex items-center gap-2"><span className="w-1 h-1 bg-gold/30 rounded-full shrink-0" /> Out-of-scope custom features</li>
                <li className="flex items-center gap-2"><span className="w-1 h-1 bg-gold/30 rounded-full shrink-0" /> Ongoing maintenance (available separately)</li>
                <li className="flex items-center gap-2"><span className="w-1 h-1 bg-gold/30 rounded-full shrink-0" /> Content writing services</li>
              </ul>
            </div>
            <p className="text-xs text-ivorySoft/30 font-sans font-light mt-6 pt-6 border-t border-white/[0.04]">
              We do not guarantee SEO rankings, sales figures, or business results. SEO and conversion depend on many factors beyond website design.
            </p>
          </div>
        </Reveal>
      </div>
    </div>
  );
}
