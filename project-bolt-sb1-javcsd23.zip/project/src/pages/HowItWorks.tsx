import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import SectionHeading from '@/components/SectionHeading';
import Reveal from '@/components/Reveal';

const steps = [
  { number: '01', title: 'Discovery Call', desc: 'We start with a conversation about your business, goals, audience, and requirements. You submit a project inquiry, and we respond within 1-2 business days with clarifying questions and an initial assessment.', deliverables: ['Project inquiry review', 'Initial consultation', 'Scope definition', 'Timeline estimate'] },
  { number: '02', title: 'Design Concept', desc: 'We craft a custom design concept that reflects your brand identity. This includes the visual direction, layout structure, typography, and color system. You review and provide feedback through structured revision rounds.', deliverables: ['Visual direction', 'Layout structure', 'Typography system', 'Revision rounds'] },
  { number: '03', title: 'Development', desc: 'We build your website with clean, modern code. Responsive across all devices, accessible by default, and optimized for performance and search engines. You see progress at key milestones.', deliverables: ['Responsive build', 'Cross-browser testing', 'Performance optimization', 'SEO foundation'] },
  { number: '04', title: 'Launch & Handover', desc: 'We finalize, test across devices and browsers, and prepare for launch. You receive documentation, a handover session, and guidance on how to manage your new website.', deliverables: ['Final testing', 'Documentation', 'Launch support', 'Post-launch guidance'] },
];

const timeline = [
  { project: 'Starter Website', time: '5-7 business days' },
  { project: 'Essential / Professional Website', time: '1-2 weeks' },
  { project: 'Business Plus / Premium Website', time: '2-3 weeks' },
  { project: 'Advanced / Elite / Signature Website', time: '3-4 weeks' },
  { project: 'Mini / Starter Store', time: '1-2 weeks' },
  { project: 'Growth / Premium / Elite Store', time: '2-4 weeks' },
];

export default function HowItWorks() {
  return (
    <div className="pt-32 pb-32 min-h-screen">
      <div className="container-lux-full">
        <Reveal>
          <div className="text-center mb-20">
            <p className="eyebrow mb-5">
              <span className="inline-block w-6 h-px bg-gold/30 align-middle mr-3" />
              Our Process
            </p>
            <h1 className="heading-display text-4xl md:text-5xl lg:text-6xl mb-6">How It Works</h1>
            <p className="text-sm text-ivorySoft/45 font-sans font-light max-w-2xl mx-auto leading-relaxed">
              A clear, collaborative process from first conversation to final launch. You always know what is happening, what comes next, and what to expect.
            </p>
          </div>
        </Reveal>

        <div className="space-y-20 mb-24">
          {steps.map((step, i) => (
            <Reveal key={step.number} delay={i * 100}>
              <div className={`grid grid-cols-1 lg:grid-cols-2 gap-16 items-center ${i % 2 === 1 ? 'lg:flex-row-reverse' : ''}`}>
                <div className={i % 2 === 1 ? 'lg:order-2' : ''}>
                  <span className="font-serif text-6xl text-gold/15 block mb-6">{step.number}</span>
                  <h2 className="font-serif text-2xl md:text-3xl text-ivory mb-4">{step.title}</h2>
                  <p className="text-sm text-ivorySoft/45 font-sans font-light leading-relaxed mb-8 max-w-lg">{step.desc}</p>
                  <div className="glass p-6 rounded-sm">
                    <p className="text-[10px] uppercase tracking-wider-2 text-gold/50 font-sans font-light mb-4">Deliverables</p>
                    <ul className="grid grid-cols-2 gap-3">
                      {step.deliverables.map((d) => (
                        <li key={d} className="text-xs font-sans font-light text-ivorySoft/55 flex items-center gap-2">
                          <span className="w-1 h-1 bg-gold/40 rounded-full shrink-0" /> {d}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                <div className={i % 2 === 1 ? 'lg:order-1' : ''}>
                  <div className="relative aspect-[16/10] overflow-hidden surface-card rounded-sm">
                    <img
                      src={`https://images.pexels.com/photos/${['31949770', '16307279', '6424583', '1170412'][i]}/pexels-photo-${['31949770', '16307279', '6424583', '1170412'][i]}.jpeg?auto=compress&cs=tinysrgb&h=800&w=1200`}
                      alt={step.title}
                      className="w-full h-full object-cover opacity-60"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-obsidian/60 to-transparent" />
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal>
          <div className="glass-elevated p-10 mb-24 rounded-sm">
            <SectionHeading eyebrow="Estimated Timelines" title="Project Duration Guide" center />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-white/[0.04] max-w-3xl mx-auto mt-12">
              {timeline.map((t) => (
                <div key={t.project} className="flex justify-between items-center py-4 px-6 bg-charcoal-dark hover:bg-white/[0.01] transition-all duration-500 ease-luxury">
                  <span className="text-sm font-sans font-light text-ivorySoft/60">{t.project}</span>
                  <span className="text-sm font-sans font-light text-gold/80">{t.time}</span>
                </div>
              ))}
            </div>
            <p className="text-xs text-ivorySoft/30 font-sans font-light text-center mt-8">
              Timelines are estimates and may vary based on project complexity, revision rounds, and client response times.
            </p>
          </div>
        </Reveal>

        <Reveal>
          <div className="text-center">
            <SectionHeading
              eyebrow="Ready to Begin?"
              title="Start Your Project Today"
              subtitle="Submit a project inquiry and we'll respond within 1-2 business days."
              center
            />
            <div className="mt-12">
              <Link to="/project-inquiry" className="btn-primary">
                Submit Project Inquiry <ArrowRight size={16} />
              </Link>
            </div>
          </div>
        </Reveal>
      </div>
    </div>
  );
}
