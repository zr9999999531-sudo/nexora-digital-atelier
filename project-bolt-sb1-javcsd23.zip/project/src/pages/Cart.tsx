import { Link } from 'react-router-dom';
import { ArrowRight, Trash2, ShoppingBag, ArrowLeft } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import Reveal from '@/components/Reveal';

export default function Cart() {
  const { items, removeItem, updateQuantity, subtotal, clearCart } = useCart();

  if (items.length === 0) {
    return (
      <div className="pt-32 pb-32 min-h-screen flex items-center">
        <div className="container-lux max-w-2xl text-center">
          <Reveal>
            <p className="eyebrow mb-5">
              <span className="inline-block w-6 h-px bg-gold/30 align-middle mr-3" />
              Shopping Cart
            </p>
            <h1 className="heading-display text-4xl md:text-5xl mb-6">Your Cart is Empty</h1>
            <p className="text-sm text-ivorySoft/45 font-sans font-light mb-10">
              Browse our collection of premium website and e-commerce templates.
            </p>
            <Link to="/shop" className="btn-primary">
              <ShoppingBag size={16} /> Shop Products
            </Link>
          </Reveal>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-32 pb-32 min-h-screen">
      <div className="container-lux-full">
        <Reveal>
          <div className="mb-12">
            <Link to="/shop" className="link-arrow mb-4 group">
              <ArrowLeft size={14} className="group-hover:-translate-x-1 transition-transform duration-500 ease-luxury" />
              Continue Shopping
            </Link>
            <h1 className="heading-display text-4xl md:text-5xl">Shopping Cart</h1>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-8">
          <Reveal>
            <div className="space-y-4">
              {items.map((item) => (
                <div key={item.product.id} className="glass p-5 flex gap-4 items-center rounded-sm">
                  <Link to={`/product/${item.product.slug}`} className="shrink-0">
                    <img src={item.product.image} alt={item.product.name} className="w-20 h-20 object-cover" />
                  </Link>
                  <div className="flex-1 min-w-0">
                    <p className="text-[10px] uppercase tracking-wider-2 text-gold/50 font-sans font-light mb-1">{item.product.industry}</p>
                    <Link to={`/product/${item.product.slug}`} className="font-serif text-base text-ivory hover:text-gold transition-colors duration-500 ease-luxury block truncate">
                      {item.product.name}
                    </Link>
                    <p className="text-xs text-ivorySoft/40 font-sans font-light mt-1">{item.product.priceLabel}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      min={1}
                      value={item.quantity}
                      onChange={(e) => updateQuantity(item.product.id, parseInt(e.target.value) || 1)}
                      className="w-16 bg-white/[0.02] border border-white/[0.08] px-2 py-1.5 text-center text-sm text-ivory focus:border-gold/40 focus:outline-none transition-all duration-500 ease-luxury"
                    />
                    <button
                      onClick={() => removeItem(item.product.id)}
                      className="text-ivorySoft/30 hover:text-red-400/70 transition-colors duration-500"
                      aria-label={`Remove ${item.product.name} from cart`}
                    >
                      <Trash2 size={16} strokeWidth={1.5} />
                    </button>
                  </div>
                  <p className="font-serif text-lg text-gold whitespace-nowrap">
                    ${(item.product.price * item.quantity).toLocaleString()} USD
                  </p>
                </div>
              ))}
              <button onClick={clearCart} className="text-[11px] uppercase tracking-wider-2 text-ivorySoft/30 hover:text-red-400/70 transition-colors duration-500 font-sans font-light">
                Clear Cart
              </button>
            </div>
          </Reveal>

          <Reveal delay={100}>
            <div className="glass-elevated p-8 h-fit sticky top-28 rounded-sm">
              <h2 className="font-serif text-xl text-ivory mb-6">Order Summary</h2>
              <div className="space-y-3 mb-6">
                <div className="flex justify-between text-sm font-sans font-light">
                  <span className="text-ivorySoft/50">Subtotal</span>
                  <span className="text-ivory">${subtotal.toLocaleString()} USD</span>
                </div>
                <div className="flex justify-between text-sm font-sans font-light">
                  <span className="text-ivorySoft/50">Taxes</span>
                  <span className="text-ivorySoft/30">Calculated at checkout</span>
                </div>
                <div className="divider-gold my-3" />
                <div className="flex justify-between">
                  <span className="font-serif text-lg text-ivory">Total</span>
                  <span className="font-serif text-xl text-gold">{subtotal.toLocaleString()} USD</span>
                </div>
              </div>
              <Link to="/checkout" className="btn-primary w-full mb-3">
                Proceed to Checkout <ArrowRight size={16} />
              </Link>
              <p className="text-xs text-ivorySoft/30 font-sans font-light text-center">
                All prices in USD. Secure checkout pending payment provider setup.
              </p>
            </div>
          </Reveal>
        </div>
      </div>
    </div>
  );
}
