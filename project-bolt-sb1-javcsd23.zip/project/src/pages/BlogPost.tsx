import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Clock, Calendar } from 'lucide-react';
import { blogPosts } from '@/data/content';
import Reveal from '@/components/Reveal';

export default function BlogPost() {
  const { slug } = useParams<{ slug: string }>();
  const post = blogPosts.find((p) => p.slug === slug);

  if (!post) {
    return (
      <div className="pt-32 pb-24 min-h-screen">
        <div className="container-lux text-center">
          <h1 className="heading-display text-4xl mb-8">Article Not Found</h1>
          <Link to="/blog" className="btn-primary">
            <ArrowLeft size={16} /> Back to Blog
          </Link>
        </div>
      </div>
    );
  }

  const related = blogPosts.filter((p) => p.id !== post.id && p.category === post.category).slice(0, 2);

  return (
    <div className="pt-32 pb-32 min-h-screen">
      <div className="container-lux max-w-3xl">
        <Reveal>
          <Link to="/blog" className="link-arrow mb-10 group">
            <ArrowLeft size={14} className="group-hover:-translate-x-1 transition-transform duration-500 ease-luxury" />
            Back to Blog
          </Link>
        </Reveal>

        <Reveal delay={100}>
          <div className="tag-lux mb-6">{post.category}</div>
          <h1 className="heading-display text-3xl md:text-4xl lg:text-5xl mb-6">{post.title}</h1>
          <div className="flex items-center gap-6 mb-12 text-xs font-sans font-light text-ivorySoft/40">
            <span className="flex items-center gap-2"><Calendar size={14} strokeWidth={1.5} className="text-gold/50" /> {post.date}</span>
            <span className="flex items-center gap-2"><Clock size={14} strokeWidth={1.5} className="text-gold/50" /> {post.readTime} read</span>
          </div>
        </Reveal>

        <Reveal delay={200}>
          <div className="relative aspect-[16/9] overflow-hidden surface-card rounded-sm mb-12">
            <img src={post.image} alt={post.title} className="w-full h-full object-cover" />
          </div>
        </Reveal>

        <Reveal delay={300}>
          <div className="text-sm md:text-base text-ivorySoft/65 font-sans font-light leading-[1.8] space-y-6 mb-16">
            {post.content.split('\n\n').map((para, i) => (
              <p key={i}>{para}</p>
            ))}
          </div>
        </Reveal>

        {related.length > 0 && (
          <Reveal>
            <div className="border-t border-white/[0.06] pt-12">
              <h2 className="font-serif text-2xl text-ivory mb-8">Related Articles</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {related.map((r) => (
                  <Link
                    key={r.id}
                    to={`/blog/${r.slug}`}
                    className="group surface-card p-8 hover:border-gold/20 transition-all duration-700 ease-luxury"
                  >
                    <p className="text-[10px] uppercase tracking-wider-2 text-gold/50 font-sans font-light mb-3">{r.category}</p>
                    <h3 className="font-serif text-base text-ivory mb-4 group-hover:text-gold transition-colors duration-700 ease-luxury">{r.title}</h3>
                    <span className="link-arrow group/link">
                      Read <ArrowRight size={12} className="group-hover/link:translate-x-1 transition-transform duration-500 ease-luxury" />
                    </span>
                  </Link>
                ))}
              </div>
            </div>
          </Reveal>
        )}
      </div>
    </div>
  );
}
