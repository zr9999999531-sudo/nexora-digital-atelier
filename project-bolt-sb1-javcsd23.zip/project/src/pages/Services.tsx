import { useParams, Link } from 'react-router-dom';
import { ArrowRight, Check } from 'lucide-react';
import { websitePackages, ecommercePackages } from '@/data/content';
import SectionHeading from '@/components/SectionHeading';
import Reveal from '@/components/Reveal';

const serviceInfo: Record<string, { title: string; eyebrow: string; description: string; audience: string; features: string[]; exclusions: string[]; packages?: typeof websitePackages }> = {
  'website-design': {
    title: 'Website Design',
    eyebrow: 'Custom Design',
    description: 'Premium, custom-designed websites built from scratch to elevate your brand. Every project is unique — no recycled layouts, no generic templates.',
    audience: 'Businesses seeking a distinctive online presence that reflects their brand quality.',
    features: ['Custom layout design', 'Responsive across all devices', 'SEO-friendly architecture', 'Accessible and keyboard-navigable', 'Performance-optimized', 'Clean, maintainable code'],
    exclusions: ['Domain registration fees', 'Web hosting subscriptions', 'Premium plugins or themes', 'Third-party service subscriptions'],
    packages: websitePackages,
  },
  'ecommerce-development': {
    title: 'E-Commerce Development',
    eyebrow: 'Online Stores',
    description: 'Powerful online stores engineered for conversion. From product catalogs to checkout flows, we build e-commerce experiences that sell.',
    audience: 'Brands ready to sell products online with a professional, conversion-optimized store.',
    features: ['Product catalog management', 'Shopping cart and checkout', 'Payment provider integration ready', 'Customer accounts ready', 'Order management', 'Mobile-optimized shopping'],
    exclusions: ['Payment provider transaction fees', 'Domain and hosting costs', 'Product photography', 'Inventory management systems'],
    packages: ecommercePackages,
  },
  'custom-website-development': {
    title: 'Custom Website Development',
    eyebrow: 'Custom Development',
    description: 'Bespoke web development for businesses that need custom functionality, integrations, or web applications beyond a standard website.',
    audience: 'Businesses requiring custom features, API integrations, or specialized web applications.',
    features: ['Custom functionality and integrations', 'API integration and development', 'Database architecture', 'User authentication systems', 'Performance optimization', 'Scalable architecture'],
    exclusions: ['Third-party API subscription costs', 'Server infrastructure', 'Ongoing maintenance (separate engagement)'],
    packages: websitePackages,
  },
  'wordpress-development': {
    title: 'WordPress Development',
    eyebrow: 'CMS Solutions',
    description: 'Flexible, content-driven websites built on WordPress. Perfect for businesses that need to update content regularly without developer involvement.',
    audience: 'Teams that need to manage and update their website content independently.',
    features: ['Custom WordPress theme', 'Plugin configuration', 'Content management training', 'SEO optimization', 'Security hardening', 'Performance tuning'],
    exclusions: ['Premium plugin licenses', 'Hosting and domain costs', 'Ongoing maintenance (separate engagement)'],
  },
  'website-redesign': {
    title: 'Website Redesign',
    eyebrow: 'Transformation',
    description: 'Transform your existing website into a modern, high-performing experience. We preserve your content while elevating design and technology.',
    audience: 'Businesses with an existing website that needs a visual and technical upgrade.',
    features: ['Design audit and strategy', 'Content migration', 'Modern framework rebuild', 'Performance improvement', 'SEO preservation', 'Redirect management'],
    exclusions: ['Original platform licensing', 'Content creation (separate engagement)'],
    packages: websitePackages,
  },
  'seo-foundations': {
    title: 'SEO Foundations',
    eyebrow: 'Search Optimization',
    description: 'Search-engine-optimized architecture built into your website from the foundation. We do not guarantee rankings — we build the technical foundation for organic growth.',
    audience: 'Businesses investing in long-term organic search visibility.',
    features: ['Semantic HTML structure', 'Meta tag optimization', 'Structured data implementation', 'Sitemap and robots.txt', 'Page speed optimization', 'Internal linking strategy'],
    exclusions: ['Content writing (separate engagement)', 'Link building campaigns', 'Ongoing SEO management'],
  },
};

export default function Services() {
  const { serviceId } = useParams<{ serviceId: string }>();
  const info = serviceInfo[serviceId || 'website-design'] || serviceInfo['website-design'];
  const otherServices = Object.entries(serviceInfo).filter(([key]) => key !== serviceId);

  return (
    <div className="pt-32 pb-32 min-h-screen">
      <div className="container-lux-full">
        <Reveal>
          <Link to="/services/website-design" className="link-arrow mb-8 group">
            <ArrowRight size={14} className="rotate-180 group-hover:-translate-x-1 transition-transform duration-500 ease-luxury" />
            All Services
          </Link>
        </Reveal>

        <Reveal delay={100}>
          <div className="max-w-3xl mb-20">
            <p className="eyebrow mb-5">
              <span className="inline-block w-6 h-px bg-gold/30 align-middle mr-3" />
              {info.eyebrow}
            </p>
            <h1 className="heading-display text-4xl md:text-5xl lg:text-6xl mb-8">{info.title}</h1>
            <p className="text-lg text-ivorySoft/50 font-sans font-light leading-relaxed mb-8">{info.description}</p>
            <div className="glass-gold p-6 rounded-sm">
              <p className="text-[10px] uppercase tracking-wider-2 text-gold/60 font-sans font-light mb-2">Intended Audience</p>
              <p className="text-sm text-ivorySoft/70 font-sans font-light">{info.audience}</p>
            </div>
          </div>
        </Reveal>

        {/* Features */}
        <Reveal delay={200}>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-white/[0.04] mb-24">
            {info.features.map((feature, i) => (
              <div key={i} className="bg-charcoal-dark p-8 flex items-start gap-3 hover:bg-white/[0.01] transition-all duration-700 ease-luxury">
                <Check size={16} strokeWidth={1.5} className="text-gold/60 mt-0.5 shrink-0" />
                <span className="text-sm font-sans font-light text-ivorySoft/70">{feature}</span>
              </div>
            ))}
          </div>
        </Reveal>

        {/* Packages */}
        {info.packages && info.packages.length > 0 && (
          <div className="mb-24">
            <Reveal>
              <SectionHeading
                eyebrow="Packages"
                title={serviceId === 'ecommerce-development' ? 'E-Commerce Packages' : 'Website Packages'}
                subtitle="Transparent pricing in USD. Additional costs for domains, hosting, and third-party services are not included."
                center
              />
            </Reveal>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-16">
              {info.packages.map((pkg, i) => (
                <Reveal key={pkg.id} delay={i * 80}>
                  <div className={`surface-card p-8 flex flex-col hover:border-gold/20 transition-all duration-700 ease-luxury h-full ${pkg.popular ? '!border-gold/25 relative glow-gold' : ''}`}>
                    {pkg.popular && (
                      <span className="absolute -top-px left-0 right-0 h-px bg-gradient-to-r from-transparent via-gold to-transparent" />
                    )}
                    {pkg.popular && (
                      <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gold text-obsidian text-[9px] uppercase tracking-wider-2 font-sans font-medium px-3 py-1">
                        Popular
                      </span>
                    )}
                    <h3 className="font-serif text-lg text-ivory mb-2">{pkg.name}</h3>
                    <p className="font-serif text-3xl text-gold mb-4">{pkg.priceLabel}</p>
                    <p className="text-xs text-ivorySoft/40 font-sans font-light leading-relaxed mb-6">{pkg.description}</p>
                    <ul className="space-y-2 mb-8 flex-1">
                      {pkg.deliverables.map((d, i) => (
                        <li key={i} className="flex items-start gap-2 text-[11px] font-sans font-light text-ivorySoft/60">
                          <Check size={11} strokeWidth={1.5} className="text-gold/50 mt-0.5 shrink-0" /> {d}
                        </li>
                      ))}
                    </ul>
                    <Link to="/project-inquiry" className="btn-outline w-full !py-3 !text-[10px]">
                      Select Package
                    </Link>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        )}

        {/* Exclusions */}
        <Reveal>
          <div className="glass p-8 mb-24">
            <SectionHeading eyebrow="Important Note" title="Exclusions & Additional Costs" />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm font-sans font-light text-ivorySoft/50 mt-6">
              <ul className="space-y-2">
                {info.exclusions.map((e) => (
                  <li key={e} className="flex items-center gap-2">
                    <span className="w-1 h-1 bg-gold/30 rounded-full shrink-0" />
                    {e}
                  </li>
                ))}
              </ul>
            </div>
            <p className="text-xs text-ivorySoft/30 font-sans font-light mt-6 pt-6 border-t border-white/[0.04]">
              We do not guarantee SEO rankings, sales figures, or specific business results. Our work provides the foundation — ongoing effort drives results.
            </p>
          </div>
        </Reveal>

        {/* Other Services */}
        <Reveal>
          <SectionHeading eyebrow="Other Services" title="Explore More" />
        </Reveal>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-white/[0.04] mt-12">
          {otherServices.map(([key, s], i) => (
            <Reveal key={key} delay={i * 80}>
              <Link
                to={`/services/${key}`}
                className="group bg-charcoal-dark p-8 block h-full hover:bg-white/[0.01] transition-all duration-700 ease-luxury"
              >
                <p className="text-[10px] uppercase tracking-wider-2 text-gold/50 font-sans font-light mb-3">{s.eyebrow}</p>
                <h3 className="font-serif text-lg text-ivory mb-4 group-hover:text-gold transition-colors duration-700 ease-luxury">{s.title}</h3>
                <span className="link-arrow group/link">
                  Learn More <ArrowRight size={12} className="group-hover/link:translate-x-1 transition-transform duration-500 ease-luxury" />
                </span>
              </Link>
            </Reveal>
          ))}
        </div>
      </div>
    </div>
  );
}
