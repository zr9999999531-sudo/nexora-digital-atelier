import { Link } from 'react-router-dom';
import { Home, ArrowRight } from 'lucide-react';
import Reveal from '@/components/Reveal';

export default function NotFound() {
  return (
    <div className="pt-32 pb-32 min-h-screen flex items-center">
      <div className="container-lux text-center">
        <Reveal>
          <p className="font-serif text-[120px] md:text-[200px] text-gold/10 leading-none">404</p>
          <p className="eyebrow mb-5 mt-4">
            <span className="inline-block w-6 h-px bg-gold/30 align-middle mr-3" />
            Page Not Found
          </p>
          <h1 className="heading-display text-3xl md:text-4xl mb-6">
            This Page Does Not Exist
          </h1>
          <p className="text-sm text-ivorySoft/45 font-sans font-light max-w-md mx-auto mb-10 leading-relaxed">
            The page you are looking for may have been moved, renamed, or is no longer available. Let us help you find what you need.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/" className="btn-primary">
              <Home size={16} /> Back to Home
            </Link>
            <Link to="/shop" className="btn-outline">
              Browse Products <ArrowRight size={16} />
            </Link>
          </div>
        </Reveal>
      </div>
    </div>
  );
}
