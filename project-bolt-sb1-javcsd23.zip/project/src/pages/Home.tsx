import { Link } from 'react-router-dom';
import { ArrowRight, ArrowUpRight, ShoppingBag, Check } from 'lucide-react';
import { websiteTemplates, ecommerceTemplates } from '@/data/products';
import { websitePackages, ecommercePackages, portfolioItems, faqItems } from '@/data/content';
import { siteConfig } from '@/data/siteConfig';
import ProductCard from '@/components/ProductCard';
import SectionHeading from '@/components/SectionHeading';
import Reveal from '@/components/Reveal';
import HeroCanvas from '@/components/HeroCanvas';
import MagneticButton from '@/components/MagneticButton';

const threeWays = [
  {
    label: 'A',
    title: 'Custom Website',
    desc: 'A bespoke website designed and built from scratch for your brand. Every pixel intentional, every interaction crafted.',
    benefits: ['Design from scratch', 'Your brand, your voice', 'SEO-optimized foundation', 'Responsive on every device'],
    cta: 'Explore Website Services',
    path: '/services/website-design',
  },
  {
    label: 'B',
    title: 'E-Commerce Store',
    desc: 'A professional online store with product catalog, cart, checkout, and payment integration. Built to convert and scale.',
    benefits: ['Complete online store', 'Cart and checkout built-in', 'Payment provider ready', 'Mobile-optimized shopping'],
    cta: 'Explore E-Commerce',
    path: '/services/ecommerce-development',
  },
  {
    label: 'C',
    title: 'Ready-Made Template',
    desc: 'Choose from 24 premium templates with complete source code. Instant download, fully customizable, from $100 USD.',
    benefits: ['24 premium templates', 'Complete source code', 'Instant download', 'From $100 USD'],
    cta: 'Shop Templates',
    path: '/shop',
  },
];

const services = [
  { num: '01', title: 'Website Design', desc: 'Custom-designed websites that elevate your brand above the ordinary.', path: '/services/website-design' },
  { num: '02', title: 'E-Commerce Development', desc: 'Online stores engineered for conversion and sustainable growth.', path: '/services/ecommerce-development' },
  { num: '03', title: 'Custom Development', desc: 'Bespoke functionality, integrations, and web applications.', path: '/services/custom-website-development' },
  { num: '04', title: 'WordPress', desc: 'Content-driven websites on the world\'s leading CMS platform.', path: '/services/wordpress-development' },
  { num: '05', title: 'Website Redesign', desc: 'Transform your existing site into a modern, premium experience.', path: '/services/website-redesign' },
  { num: '06', title: 'SEO Foundations', desc: 'Search-optimized architecture built in from the foundation.', path: '/services/seo-foundations' },
];

const principles = [
  { num: '01', title: 'Craft Over Volume', desc: 'Every project receives undivided attention. We prioritize quality over quantity — always.' },
  { num: '02', title: 'International by Design', desc: 'Built for global audiences with USD pricing, responsive design, and cross-border performance.' },
  { num: '03', title: 'Honesty First', desc: 'No fabricated results, no false guarantees, no hidden costs. Transparent from first conversation to final delivery.' },
  { num: '04', title: 'Engineering Excellence', desc: 'Clean, maintainable code is the foundation of everything we build and every template we sell.' },
];

const processSteps = [
  { number: '01', title: 'Discovery', desc: 'We discuss your business, goals, audience, and requirements to define the project scope.' },
  { number: '02', title: 'Design', desc: 'We craft a custom design concept reflecting your brand, refined through collaborative feedback.' },
  { number: '03', title: 'Development', desc: 'We build with clean, modern code — responsive, accessible, and optimized for performance.' },
  { number: '04', title: 'Delivery', desc: 'We launch, test across devices, and hand over with documentation and support guidance.' },
];

export default function Home() {
  const featuredPortfolio = portfolioItems.slice(0, 3);
  const websitePricing = websitePackages.slice(0, 4);
  const ecommercePricing = ecommercePackages.slice(0, 3);
  const homeFaqs = faqItems.filter((f) => f.category === 'General' || f.category === 'Services').slice(0, 4);
  const featuredWebsiteTemplates = websiteTemplates.filter((p) => p.featured).slice(0, 4);
  const featuredEcommerceTemplates = ecommerceTemplates.slice(0, 4);

  return (
    <div>
      {/* ====== HERO ====== */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        <HeroCanvas />
        <div className="container-lux-full relative z-10 py-32 lg:py-40">
          <div className="max-w-4xl">
            <Reveal delay={100}>
              <p className="eyebrow mb-8">{siteConfig.fullName}</p>
            </Reveal>
            <Reveal delay={300}>
              <h1 className="heading-display text-5xl md:text-7xl lg:text-8xl mb-8 text-balance">
                Crafting Digital
                <br />
                <span className="text-gradient-gold">Sovereignty</span>
                <br />
                <span className="text-ivorySoft/40 font-serif italic font-normal text-4xl md:text-6xl lg:text-7xl">for Elite Brands</span>
              </h1>
            </Reveal>
            <Reveal delay={600}>
              <p className="text-lg lg:text-xl text-ivorySoft/50 font-sans font-light leading-relaxed mb-12 max-w-2xl">
                Premium websites, powerful online stores, and thoughtfully crafted digital solutions for ambitious brands across the USA, Dubai, Europe, and beyond.
              </p>
            </Reveal>
            <Reveal delay={900}>
              <div className="flex flex-col sm:flex-row gap-4">
                <MagneticButton to="/services/website-design" className="btn-primary">
                  Explore Our Services <ArrowRight size={16} />
                </MagneticButton>
                <MagneticButton to="/shop/website-templates" className="btn-outline" strength={0.2}>
                  <ShoppingBag size={16} /> Shop Website Templates
                </MagneticButton>
                <Link to="/project-inquiry" className="btn-ghost">
                  Start a Project <ArrowRight size={14} />
                </Link>
              </div>
            </Reveal>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 hidden md:block">
          <div className="flex flex-col items-center gap-3">
            <span className="text-[9px] uppercase tracking-mega-wide text-ivorySoft/30 font-sans font-light">Scroll</span>
            <div className="w-px h-12 bg-gradient-to-b from-gold/40 to-transparent animate-shimmer" />
          </div>
        </div>
      </section>

      {/* ====== MARQUEE ====== */}
      <div className="overflow-hidden border-y border-white/[0.04] py-6 bg-obsidian">
        <div className="marquee-text flex gap-16 text-2xl md:text-3xl font-serif italic text-ivorySoft/15">
          {[
            'Premium Websites', '—', 'Powerful Online Stores', '—', 'Digital Identity', '—',
            'Luxury Web Design', '—', 'E-Commerce Excellence', '—', 'Elite Brand Experiences', '—',
            'Premium Websites', '—', 'Powerful Online Stores', '—', 'Digital Identity', '—',
            'Luxury Web Design', '—', 'E-Commerce Excellence', '—', 'Elite Brand Experiences', '—',
          ].map((t, i) => (
            <span key={i} className="shrink-0">{t}</span>
          ))}
        </div>
      </div>

      {/* ====== THREE WAYS TO WORK ====== */}
      <section className="py-32 bg-obsidian">
        <div className="container-lux-full">
          <Reveal>
            <SectionHeading
              eyebrow="Three Ways to Work With Us"
              title="Choose Your Path"
              subtitle="Whether you need a custom-built website, a full e-commerce store, or a ready-made template — we have a solution designed for your ambitions."
              center
            />
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-white/[0.04] mt-16">
            {threeWays.map((option, i) => (
              <Reveal key={option.title} delay={i * 150}>
                <div className="bg-obsidian p-10 lg:p-12 h-full flex flex-col group transition-all duration-700 ease-luxury hover:bg-white/[0.01]">
                  <div className="flex items-center justify-between mb-8">
                    <span className="font-serif text-5xl text-gold/20 group-hover:text-gold/40 transition-colors duration-700">{option.label}</span>
                    <div className="w-10 h-10 border border-gold/15 rounded-full flex items-center justify-center group-hover:border-gold/40 transition-colors duration-700">
                      <ArrowRight size={14} className="text-gold/40 group-hover:text-gold transition-colors duration-700" />
                    </div>
                  </div>
                  <h3 className="font-serif text-2xl text-ivory mb-4">{option.title}</h3>
                  <p className="text-sm text-ivorySoft/50 font-sans font-light leading-relaxed mb-8">{option.desc}</p>
                  <ul className="space-y-2.5 mb-10 flex-1">
                    {option.benefits.map((b) => (
                      <li key={b} className="flex items-start gap-3 text-xs font-sans font-light text-ivorySoft/60">
                        <Check size={14} strokeWidth={1.5} className="text-gold/60 mt-0.5 shrink-0" />
                        {b}
                      </li>
                    ))}
                  </ul>
                  <Link to={option.path} className="link-arrow group/link">
                    {option.cta}
                    <ArrowRight size={14} className="group-hover/link:translate-x-1 transition-transform duration-500 ease-luxury" />
                  </Link>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ====== SERVICES BENTO GRID ====== */}
      <section className="py-32 bg-charcoal-dark">
        <div className="container-lux-full">
          <Reveal>
            <div className="flex items-end justify-between mb-16 flex-wrap gap-6">
              <SectionHeading
                eyebrow="What We Do"
                title="Services"
                subtitle="A complete range of digital services for brands that refuse to be ordinary."
              />
              <Link to="/services/website-design" className="link-arrow group">
                All Services <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform duration-500 ease-luxury" />
              </Link>
            </div>
          </Reveal>

          {/* Bento grid: 2 large + 4 small */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-white/[0.04]">
            {/* Large card 1 */}
            <Reveal className="lg:col-span-2 lg:row-span-1">
              <Link to="/services/website-design" className="block bg-charcoal-dark p-10 lg:p-14 h-full group transition-all duration-700 ease-luxury hover:bg-white/[0.01] relative overflow-hidden">
                <div className="absolute top-0 right-0 w-40 h-40 rounded-full opacity-[0.03] blur-3xl group-hover:opacity-[0.08] transition-opacity duration-1000" style={{ background: '#c9a96e' }} />
                <span className="font-serif text-4xl text-gold/20 block mb-4">{services[0].num}</span>
                <h3 className="font-serif text-3xl text-ivory mb-4 group-hover:text-gold transition-colors duration-700">{services[0].title}</h3>
                <p className="text-sm text-ivorySoft/50 font-sans font-light leading-relaxed max-w-md">{services[0].desc}</p>
                <span className="link-arrow mt-8 group/link">
                  Learn More <ArrowUpRight size={14} className="group-hover/link:translate-x-0.5 group-hover/link:-translate-y-0.5 transition-transform duration-500" />
                </span>
              </Link>
            </Reveal>
            {/* Small cards */}
            {services.slice(1).map((s, i) => (
              <Reveal key={s.title} delay={i * 100}>
                <Link to={s.path} className="block bg-charcoal-dark p-8 lg:p-10 h-full group transition-all duration-700 ease-luxury hover:bg-white/[0.01]">
                  <span className="font-serif text-2xl text-gold/20 block mb-3">{s.num}</span>
                  <h3 className="font-serif text-xl text-ivory mb-2 group-hover:text-gold transition-colors duration-700">{s.title}</h3>
                  <p className="text-xs text-ivorySoft/40 font-sans font-light leading-relaxed">{s.desc}</p>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ====== FEATURED TEMPLATES ====== */}
      <section className="py-32 bg-obsidian">
        <div className="container-lux-full">
          <Reveal>
            <div className="flex items-end justify-between mb-16 flex-wrap gap-6">
              <SectionHeading
                eyebrow="Website Templates"
                title="Featured Designs"
                subtitle="Premium, ready-to-use website templates crafted for distinct industries."
              />
              <Link to="/shop/website-templates" className="link-arrow group">
                View All <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform duration-500 ease-luxury" />
              </Link>
            </div>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredWebsiteTemplates.map((product, i) => (
              <Reveal key={product.id} delay={i * 100}>
                <ProductCard product={product} />
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ====== E-COMMERCE TEMPLATES ====== */}
      <section className="py-32 bg-charcoal-dark">
        <div className="container-lux-full">
          <Reveal>
            <div className="flex items-end justify-between mb-16 flex-wrap gap-6">
              <SectionHeading
                eyebrow="E-Commerce Templates"
                title="Store Solutions"
                subtitle="Complete online store templates with cart, checkout, and product management."
              />
              <Link to="/shop/ecommerce-templates" className="link-arrow group">
                View All <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform duration-500 ease-luxury" />
              </Link>
            </div>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredEcommerceTemplates.map((product, i) => (
              <Reveal key={product.id} delay={i * 100}>
                <ProductCard product={product} />
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ====== PRINCIPLES ====== */}
      <section className="py-32 bg-obsidian">
        <div className="container-lux-full">
          <Reveal>
            <SectionHeading
              eyebrow="Our Standards"
              title="Why NEXORA"
              subtitle="We hold ourselves to a standard that goes beyond delivering a website — we craft digital experiences worthy of your brand."
              center
            />
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-white/[0.04] mt-16">
            {principles.map((p, i) => (
              <Reveal key={p.title} delay={i * 120}>
                <div className="bg-obsidian p-10 h-full group transition-all duration-700 ease-luxury hover:bg-white/[0.01]">
                  <span className="font-serif text-3xl text-gold/20 block mb-6">{p.num}</span>
                  <div className="h-px w-10 bg-gold/30 mb-6 group-hover:w-16 transition-all duration-700 ease-luxury" />
                  <h3 className="font-serif text-lg text-ivory mb-4">{p.title}</h3>
                  <p className="text-xs text-ivorySoft/40 font-sans font-light leading-relaxed">{p.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ====== PROCESS ====== */}
      <section className="py-32 bg-charcoal-dark">
        <div className="container-lux-full">
          <Reveal>
            <SectionHeading
              eyebrow="Our Approach"
              title="The Process"
              subtitle="A clear, collaborative process from first conversation to final delivery."
              center
            />
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-16">
            {processSteps.map((step, i) => (
              <Reveal key={step.number} delay={i * 150}>
                <div className="relative">
                  <span className="font-serif text-6xl text-gold/15 block mb-6">{step.number}</span>
                  <div className="h-px w-12 bg-gold/25 mb-6" />
                  <h3 className="font-serif text-xl text-ivory mb-3">{step.title}</h3>
                  <p className="text-sm text-ivorySoft/50 font-sans font-light leading-relaxed">{step.desc}</p>
                </div>
              </Reveal>
            ))}
          </div>
          <Reveal delay={400}>
            <div className="text-center mt-16">
              <Link to="/how-it-works" className="btn-outline">
                See Full Process <ArrowRight size={16} />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ====== PORTFOLIO ====== */}
      <section className="py-32 bg-obsidian">
        <div className="container-lux-full">
          <Reveal>
            <div className="flex items-end justify-between mb-16 flex-wrap gap-6">
              <SectionHeading
                eyebrow="Concept Work"
                title="Selected Portfolio"
                subtitle="Concept projects demonstrating our approach to luxury digital design."
              />
              <Link to="/portfolio" className="link-arrow group">
                View All <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform duration-500 ease-luxury" />
              </Link>
            </div>
          </Reveal>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {featuredPortfolio.map((item, i) => (
              <Reveal key={item.id} delay={i * 150}>
                <Link
                  to={`/portfolio/${item.slug}`}
                  className="group surface-card overflow-hidden hover:border-gold/20 transition-all duration-700 ease-luxury block"
                >
                  <div className="relative aspect-[4/3] overflow-hidden bg-obsidian">
                    <img src={item.image} alt={item.title} loading="lazy" className="w-full h-full object-cover transition-transform duration-[1.2s] ease-luxury group-hover:scale-[1.06] opacity-85 group-hover:opacity-100" />
                    <div className="absolute inset-0 bg-gradient-to-t from-obsidian/80 via-transparent to-transparent" />
                    {item.isConcept && (
                      <div className="absolute top-4 left-4 tag-lux">Concept</div>
                    )}
                  </div>
                  <div className="p-6">
                    <p className="text-[10px] uppercase tracking-wider-2 text-gold/50 font-sans font-light mb-2">{item.category}</p>
                    <h3 className="font-serif text-xl text-ivory group-hover:text-gold transition-colors duration-700 ease-luxury">{item.title}</h3>
                  </div>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ====== PRICING ====== */}
      <section className="py-32 bg-charcoal-dark">
        <div className="container-lux-full">
          <Reveal>
            <SectionHeading
              eyebrow="Transparent Pricing"
              title="Pricing Overview"
              subtitle="Website packages from $150 USD. E-commerce from $100 USD. All prices in USD for clients worldwide."
              center
            />
          </Reveal>
          <Reveal delay={200}>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8 mt-16">
              {websitePricing.map((pkg) => (
                <div key={pkg.id} className="surface-card p-8 hover:border-gold/20 transition-all duration-700 ease-luxury group">
                  <h4 className="font-serif text-base text-ivory mb-3 group-hover:text-gold transition-colors duration-700">{pkg.name}</h4>
                  <p className="font-serif text-3xl text-gold mb-4">{pkg.priceLabel}</p>
                  <p className="text-xs text-ivorySoft/40 font-sans font-light leading-relaxed">{pkg.description}</p>
                </div>
              ))}
            </div>
          </Reveal>
          <Reveal delay={300}>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12">
              {ecommercePricing.map((pkg) => (
                <div key={pkg.id} className={`surface-card p-8 hover:border-gold/20 transition-all duration-700 ease-luxury group ${pkg.popular ? '!border-gold/25' : ''}`}>
                  <h4 className="font-serif text-base text-ivory mb-3 group-hover:text-gold transition-colors duration-700">{pkg.name}</h4>
                  <p className="font-serif text-3xl text-gold mb-4">{pkg.priceLabel}</p>
                  <p className="text-xs text-ivorySoft/40 font-sans font-light leading-relaxed">{pkg.description}</p>
                </div>
              ))}
            </div>
          </Reveal>
          <Reveal delay={400}>
            <div className="text-center">
              <Link to="/pricing" className="btn-primary">
                View Full Pricing <ArrowRight size={16} />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ====== FAQ ====== */}
      <section className="py-32 bg-obsidian">
        <div className="container-lux max-w-3xl">
          <Reveal>
            <SectionHeading eyebrow="Questions" title="Frequently Asked" center />
          </Reveal>
          <div className="space-y-px bg-white/[0.04] mt-16">
            {homeFaqs.map((faq, i) => (
              <Reveal key={i} delay={i * 80}>
                <details className="group bg-obsidian cursor-pointer">
                  <summary className="flex items-center justify-between list-none p-6 lg:p-8">
                    <span className="font-serif text-base lg:text-lg text-ivory pr-4">{faq.question}</span>
                    <span className="text-gold/50 text-2xl font-light group-open:rotate-45 transition-transform duration-500 ease-luxury shrink-0">+</span>
                  </summary>
                  <p className="px-6 lg:px-8 pb-6 lg:pb-8 text-sm text-ivorySoft/50 font-sans font-light leading-relaxed">{faq.answer}</p>
                </details>
              </Reveal>
            ))}
          </div>
          <Reveal delay={200}>
            <div className="text-center mt-12">
              <Link to="/faq" className="btn-ghost">
                All FAQs <ArrowRight size={14} />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ====== FINAL CTA ====== */}
      <section className="py-40 bg-charcoal border-t border-white/[0.04] relative overflow-hidden">
        {/* Glow */}
        <div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] rounded-full opacity-[0.05] blur-[120px] pointer-events-none"
          style={{ background: 'radial-gradient(circle, #c9a96e 0%, transparent 70%)' }}
        />
        <div className="container-lux text-center relative">
          <Reveal>
            <p className="eyebrow mb-6">Ready to Begin?</p>
          </Reveal>
          <Reveal delay={150}>
            <h2 className="heading-display text-5xl md:text-6xl lg:text-7xl mb-8 text-balance">
              Let's Craft Something
              <br />
              <span className="text-gradient-gold italic font-normal">Exceptional</span>
            </h2>
          </Reveal>
          <Reveal delay={300}>
            <p className="text-base text-ivorySoft/50 font-sans font-light leading-relaxed max-w-xl mx-auto mb-12">
              Share your project vision with us. We'll respond within 1-2 business days with next steps and a proposed timeline. No obligation.
            </p>
          </Reveal>
          <Reveal delay={450}>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <MagneticButton to="/project-inquiry" className="btn-primary">
                Start a Project <ArrowRight size={16} />
              </MagneticButton>
              <MagneticButton to="/shop" className="btn-outline" strength={0.2}>
                <ShoppingBag size={16} /> Shop Templates
              </MagneticButton>
              <Link to="/contact" className="btn-ghost">
                Contact Us <ArrowRight size={14} />
              </Link>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
