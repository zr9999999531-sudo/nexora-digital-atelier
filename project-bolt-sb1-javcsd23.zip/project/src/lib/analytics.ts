import { siteConfig } from '@/data/siteConfig';

type ConsentState = 'granted' | 'denied' | 'pending';

const CONSENT_KEY = 'nexora-cookie-consent';

export function getConsent(): ConsentState {
  try {
    const stored = localStorage.getItem(CONSENT_KEY);
    if (stored === 'granted' || stored === 'denied') return stored;
  } catch {
    // ignore
  }
  return 'pending';
}

export function setConsent(state: 'granted' | 'denied') {
  try {
    localStorage.setItem(CONSENT_KEY, state);
  } catch {
    // ignore
  }
  if (state === 'granted') {
    initAnalytics();
  }
}

export function initAnalytics() {
  if (!siteConfig.analytics.enabled) return;
  if (getConsent() !== 'granted') return;

  if (siteConfig.analytics.ga4Id && typeof window !== 'undefined') {
    const gaId = siteConfig.analytics.ga4Id;
    const script = document.createElement('script');
    script.async = true;
    script.src = `https://www.googletagmanager.com/gtag/js?id=${gaId}`;
    document.head.appendChild(script);

    window.dataLayer = window.dataLayer || [];
    window.gtag = function gtag(...args: unknown[]) {
      window.dataLayer.push(args);
    };
    window.gtag('js', new Date());
    window.gtag('config', gaId, { anonymize_ip: true });
  }

  if (siteConfig.analytics.metaPixelId && typeof window !== 'undefined') {
    const pixelId = siteConfig.analytics.metaPixelId;
    (window as unknown as Record<string, unknown>).fbq = function fbq(...args: unknown[]) {
      const w = window as unknown as Record<string, unknown[]>;
      w.fbqQueue = w.fbqQueue || [];
      w.fbqQueue.push(args);
    };
    const fbScript = document.createElement('script');
    fbScript.text = `!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','${pixelId}');fbq('track','PageView');`;
    document.head.appendChild(fbScript);
  }
}

export function trackEvent(eventName: string, params?: Record<string, unknown>) {
  if (typeof window === 'undefined') return;
  if (!siteConfig.analytics.enabled) return;
  if (getConsent() !== 'granted') return;

  if (window.gtag) {
    window.gtag('event', eventName, params);
  }
  const fbq = (window as unknown as Record<string, unknown>).fbq;
  if (typeof fbq === 'function') {
    fbq('track', eventName, params);
  }
}

export function trackPageView(path: string) {
  if (typeof window === 'undefined') return;
  if (!siteConfig.analytics.enabled) return;
  if (getConsent() !== 'granted') return;

  if (window.gtag && siteConfig.analytics.ga4Id) {
    window.gtag('config', siteConfig.analytics.ga4Id, { page_path: path });
  }
}
