export type ProductCategory = 'website' | 'ecommerce';

export interface ProductFile {
  name: string;
  type: string;
  size: string;
  path: string;
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  category: ProductCategory;
  industry: string;
  price: number;
  priceLabel: string;
  image: string;
  gallery: string[];
  shortDescription: string;
  description: string;
  audience: string;
  features: string[];
  includedPages: string[];
  technology: string[];
  responsive: string;
  installation: string;
  delivery: string;
  support: string;
  license: string;
  demoUrl?: string;
  files: ProductFile[];
  featured?: boolean;
}

export interface ServicePackage {
  id: string;
  name: string;
  price: number;
  priceLabel: string;
  category: 'website' | 'ecommerce';
  description: string;
  deliverables: string[];
  popular?: boolean;
}

export interface PortfolioItem {
  id: string;
  slug: string;
  title: string;
  category: string;
  client: string;
  year: string;
  image: string;
  excerpt: string;
  description: string;
  services: string[];
  isConcept: boolean;
}

export interface BlogPost {
  id: string;
  slug: string;
  title: string;
  category: string;
  excerpt: string;
  content: string;
  date: string;
  readTime: string;
  image: string;
}

export interface FAQItem {
  question: string;
  answer: string;
  category: string;
}
