import type { Product } from '@/types';
import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  return (
    <Link
      to={`/product/${product.slug}`}
      className="group surface-card overflow-hidden hover:border-gold/20 transition-all duration-700 ease-luxury flex flex-col"
    >
      <div className="relative aspect-[4/3] overflow-hidden bg-obsidian">
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          className="w-full h-full object-cover transition-transform duration-[1.2s] ease-luxury group-hover:scale-[1.06] opacity-85 group-hover:opacity-100"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-obsidian/60 to-transparent" />
        <div className="absolute top-4 left-4 tag-lux">
          {product.category === 'website' ? 'Website' : 'E-Commerce'}
        </div>
        {product.featured && (
          <div className="absolute top-4 right-4 tag-lux !border-champagne/30 !text-champagne/80">
            Featured
          </div>
        )}
      </div>
      <div className="p-6 flex flex-col flex-1">
        <p className="text-[10px] uppercase tracking-wider-2 text-gold/50 font-sans font-light mb-2">{product.industry}</p>
        <h3 className="font-serif text-lg text-ivory mb-3 group-hover:text-gold transition-colors duration-700 ease-luxury">
          {product.name}
        </h3>
        <p className="text-xs text-ivorySoft/40 font-sans font-light leading-relaxed mb-6 flex-1">
          {product.shortDescription}
        </p>
        <div className="flex items-center justify-between pt-4 border-t border-white/[0.04]">
          <span className="font-serif text-xl text-gold">{product.priceLabel}</span>
          <span className="link-arrow group/link">
            View <ArrowUpRight size={14} className="group-hover/link:translate-x-0.5 group-hover/link:-translate-y-0.5 transition-transform duration-500 ease-luxury" />
          </span>
        </div>
      </div>
    </Link>
  );
}
