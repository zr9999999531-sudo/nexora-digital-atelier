import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { blogPosts, portfolioItems } from '@/data/content';
import { getProductBySlug } from '@/data/products';

const siteUrl = 'https://nexora-digital-ateli-bz5u.bolt.host';
const brandName = 'NEXORA Digital Atelier';
const defaultDescription = 'Premium websites, powerful e-commerce stores, and thoughtful digital solutions for ambitious brands serving customers worldwide.';

type PageMeta = { title: string; description: string; noindex?: boolean };

const pageMeta: Record<string, PageMeta> = {
  '/': { title: 'NEXORA Digital Atelier | Premium Web Design & E-Commerce', description: 'NEXORA Digital Atelier creates premium websites, custom web experiences, and powerful e-commerce stores for businesses worldwide.' },
  '/about': { title: `About | ${brandName}`, description: 'Learn how NEXORA combines refined design, modern web development, and honest collaboration to build better digital experiences for international clients.' },
  '/pricing': { title: `Website & E-Commerce Pricing | ${brandName}`, description: 'Explore transparent USD pricing for premium website design, custom development, and e-commerce store packages from NEXORA.' },
  '/how-it-works': { title: `How It Works | ${brandName}`, description: 'Discover NEXORA’s clear process for planning, designing, developing, testing, and launching premium websites and online stores.' },
  '/faq': { title: `FAQ | ${brandName}`, description: 'Find answers about NEXORA services, website templates, e-commerce development, pricing, payments, delivery, and support.' },
  '/contact': { title: `Contact | ${brandName}`, description: `Contact ${brandName} about premium website design, e-commerce development, digital products, or an international project.` },
  '/project-inquiry': { title: `Start a Project | ${brandName}`, description: 'Tell NEXORA about your website, e-commerce, or custom development project and receive clear next steps.' },
  '/portfolio': { title: `Portfolio | ${brandName}`, description: 'View NEXORA concept work across luxury fashion, architecture, beauty, professional services, hospitality, real estate, and e-commerce.' },
  '/blog': { title: `Insights on Web Design & E-Commerce | ${brandName}`, description: 'Practical insights from NEXORA on luxury website design, e-commerce conversion, WordPress, performance, digital business, and SEO foundations.' },
  '/shop': { title: `Premium Website & E-Commerce Templates | ${brandName}`, description: 'Browse NEXORA digital products: premium website templates and complete e-commerce templates with source code and documentation.' },
  '/shop/website-templates': { title: `Website Templates | ${brandName}`, description: 'Shop premium, responsive website templates from NEXORA for professional brands and businesses.' },
  '/shop/ecommerce-templates': { title: `E-Commerce Templates | ${brandName}`, description: 'Shop complete e-commerce templates from NEXORA with product catalogs, cart, checkout, and responsive shopping experiences.' },
  '/privacy-policy': { title: `Privacy Policy | ${brandName}`, description: `Read the ${brandName} privacy policy and learn how information is handled.` },
  '/terms': { title: `Terms & Conditions | ${brandName}`, description: `Read the terms and conditions for using the ${brandName} website and digital products.` },
  '/refund-policy': { title: `Refund & Digital Product Policy | ${brandName}`, description: 'Read the NEXORA policy for digital product purchases, refunds, and technical support.' },
};

function getMeta(pathname: string): PageMeta {
  const exact = pageMeta[pathname];
  if (exact) return exact;

  const serviceMatch = pathname.match(/^\/services\/([^/]+)$/);
  if (serviceMatch) {
    const serviceNames: Record<string, string> = {
      'website-design': 'Website Design',
      'ecommerce-development': 'E-Commerce Development',
      'custom-website-development': 'Custom Website Development',
      'wordpress-development': 'WordPress Development',
      'website-redesign': 'Website Redesign',
      'seo-foundations': 'SEO Foundations',
    };
    const serviceName = serviceNames[serviceMatch[1]];
    if (serviceName) return { title: `${serviceName} | ${brandName}`, description: `Explore NEXORA ${serviceName.toLowerCase()} for responsive, accessible, performance-focused digital experiences serving international brands.` };
  }

  const blog = pathname.startsWith('/blog/') ? blogPosts.find((post) => `/blog/${post.slug}` === pathname) : undefined;
  if (blog) return { title: `${blog.title} | ${brandName}`, description: blog.excerpt };

  const portfolio = pathname.startsWith('/portfolio/') ? portfolioItems.find((item) => `/portfolio/${item.slug}` === pathname) : undefined;
  if (portfolio) return { title: `${portfolio.title} | ${brandName}`, description: portfolio.excerpt };

  const product = pathname.startsWith('/product/') ? getProductBySlug(pathname.replace('/product/', '')) : undefined;
  if (product) return { title: `${product.name} | ${brandName}`, description: product.shortDescription };

  if (pathname.startsWith('/lp/')) {
    const label = pathname.replace('/lp/', '').split('-').map((word) => word[0].toUpperCase() + word.slice(1)).join(' ');
    return { title: `${label} | ${brandName}`, description: `${label} from ${brandName}, built for ambitious brands and international customers.` };
  }

  return { title: `Page Not Found | ${brandName}`, description: defaultDescription, noindex: true };
}

function setMeta(attribute: 'name' | 'property', key: string, content: string) {
  let element = document.head.querySelector<HTMLMetaElement>(`meta[${attribute}="${key}"]`);
  if (!element) {
    element = document.createElement('meta');
    element.setAttribute(attribute, key);
    document.head.appendChild(element);
  }
  element.content = content;
}

export default function Seo() {
  const { pathname } = useLocation();

  useEffect(() => {
    const meta = getMeta(pathname);
    const canonicalUrl = `${siteUrl}${pathname === '/' ? '/' : pathname}`;
    document.title = meta.title;
    setMeta('name', 'description', meta.description);
    setMeta('property', 'og:title', meta.title);
    setMeta('property', 'og:description', meta.description);
    setMeta('property', 'og:url', canonicalUrl);
    setMeta('property', 'og:site_name', brandName);
    setMeta('property', 'og:type', 'website');
    setMeta('name', 'twitter:title', meta.title);
    setMeta('name', 'twitter:description', meta.description);
    setMeta('name', 'robots', meta.noindex ? 'noindex, nofollow' : 'index, follow');

    let canonical = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.rel = 'canonical';
      document.head.appendChild(canonical);
    }
    canonical.href = canonicalUrl;
  }, [pathname]);

  return null;
}
