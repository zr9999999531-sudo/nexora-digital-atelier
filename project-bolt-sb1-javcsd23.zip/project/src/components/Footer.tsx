import { Link } from 'react-router-dom';
import { Mail, MapPin, ArrowRight, ArrowUpRight } from 'lucide-react';
import { siteConfig } from '@/data/siteConfig';

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="bg-obsidian border-t border-white/[0.04] pt-24 pb-10 relative overflow-hidden">
      {/* Subtle glow */}
      <div
        className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] rounded-full opacity-[0.04] blur-[100px] pointer-events-none"
        style={{ background: 'radial-gradient(circle, #c9a96e 0%, transparent 70%)' }}
      />

      <div className="container-lux-full relative">
        {/* Top: Brand statement */}
        <div className="grid grid-cols-1 lg:grid-cols-[1.2fr_1fr_1fr_1fr] gap-12 lg:gap-16 mb-20">
          <div>
            <Link to="/" className="font-serif text-3xl tracking-wider-2 text-ivory hover:text-gold transition-colors duration-700 ease-luxury">
              NEXORA
            </Link>
            <p className="text-[9px] uppercase tracking-mega-wide text-gold/50 font-sans font-light mt-2 mb-6">
              Digital Atelier
            </p>
            <p className="text-sm text-ivorySoft/50 leading-relaxed font-sans font-light max-w-xs">
              Crafting digital sovereignty for elite brands. Premium websites, powerful online stores, and thoughtfully designed digital products.
            </p>
            <div className="mt-8">
              <Link to="/project-inquiry" className="link-arrow group">
                Start a Project
                <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform duration-500 ease-luxury" />
              </Link>
            </div>
          </div>

          <div>
            <h4 className="eyebrow mb-6">Services</h4>
            <ul className="space-y-3.5 text-sm font-sans font-light">
              {[
                { label: 'Website Design', path: '/services/website-design' },
                { label: 'Custom Development', path: '/services/custom-website-development' },
                { label: 'E-Commerce', path: '/services/ecommerce-development' },
                { label: 'WordPress', path: '/services/wordpress-development' },
                { label: 'Website Redesign', path: '/services/website-redesign' },
                { label: 'SEO Foundations', path: '/services/seo-foundations' },
              ].map((item) => (
                <li key={item.path}>
                  <Link to={item.path} className="text-ivorySoft/50 hover:text-gold transition-colors duration-500 ease-luxury">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="eyebrow mb-6">Explore</h4>
            <ul className="space-y-3.5 text-sm font-sans font-light">
              {[
                { label: 'Digital Products', path: '/shop' },
                { label: 'Website Templates', path: '/shop/website-templates' },
                { label: 'E-Commerce Templates', path: '/shop/ecommerce-templates' },
                { label: 'Portfolio', path: '/portfolio' },
                { label: 'Pricing', path: '/pricing' },
                { label: 'Blog', path: '/blog' },
                { label: 'FAQ', path: '/faq' },
              ].map((item) => (
                <li key={item.path}>
                  <Link to={item.path} className="text-ivorySoft/50 hover:text-gold transition-colors duration-500 ease-luxury">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="eyebrow mb-6">Contact</h4>
            <ul className="space-y-3.5 text-sm font-sans font-light text-ivorySoft/50">
              {siteConfig.email && (
                <li>
                  <a
                    href={`mailto:${siteConfig.email}`}
                    className="flex items-center gap-2 hover:text-gold transition-colors duration-500 ease-luxury"
                  >
                    <Mail size={14} strokeWidth={1.5} className="text-gold/40" />
                    {siteConfig.email}
                  </a>
                </li>
              )}
              <li className="flex items-center gap-2">
                <MapPin size={14} strokeWidth={1.5} className="text-gold/40" />
                <span>{siteConfig.address}</span>
              </li>
            </ul>
            <Link to="/contact" className="link-arrow mt-6 group">
              Contact Us
              <ArrowUpRight size={14} className="group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform duration-500 ease-luxury" />
            </Link>
          </div>
        </div>

        {/* Divider */}
        <div className="divider-gold mb-8" />

        {/* Bottom bar */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-[11px] font-sans font-light text-ivorySoft/35 uppercase tracking-wider-2">
          <p>&copy; {year} {siteConfig.fullName}</p>
          <div className="flex flex-wrap gap-6">
            <Link to="/privacy-policy" className="hover:text-gold/60 transition-colors duration-500">Privacy</Link>
            <Link to="/terms" className="hover:text-gold/60 transition-colors duration-500">Terms</Link>
            <Link to="/refund-policy" className="hover:text-gold/60 transition-colors duration-500">Refunds</Link>
          </div>
          <p>All prices in USD · Worldwide</p>
        </div>
      </div>
    </footer>
  );
}
