import { useEffect, useRef } from 'react';

/**
 * Abstract cinematic hero canvas with floating geometric shapes,
 * custom glow filters, and subtle particle connections.
 * Uses SVG + CSS animation for performance — no heavy canvas rendering.
 */
export default function HeroCanvas() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    let mouseX = 0;
    let mouseY = 0;
    const rafId = 0;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      mouseX = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
      mouseY = ((e.clientY - rect.top) / rect.height - 0.5) * 2;

      container.style.setProperty('--mouse-x', `${mouseX * 20}px`);
      container.style.setProperty('--mouse-y', `${mouseY * 20}px`);
    };

    container.addEventListener('mousemove', handleMouseMove);
    return () => {
      container.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(rafId);
    };
  }, []);

  return (
    <div ref={containerRef} className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Gradient orbs with glow */}
      <div
        className="absolute top-[15%] right-[10%] w-[500px] h-[500px] rounded-full opacity-30 blur-[120px] animate-glow-pulse"
        style={{
          background: 'radial-gradient(circle, rgba(201,169,110,0.4) 0%, transparent 70%)',
          transform: 'translate(var(--mouse-x, 0), var(--mouse-y, 0))',
          transition: 'transform 1.5s cubic-bezier(0.22,1,0.36,1)',
        }}
      />
      <div
        className="absolute bottom-[10%] left-[5%] w-[400px] h-[400px] rounded-full opacity-20 blur-[100px] animate-glow-pulse"
        style={{
          background: 'radial-gradient(circle, rgba(192,192,192,0.3) 0%, transparent 70%)',
          animationDelay: '2s',
          transform: 'translate(calc(var(--mouse-x, 0) * -1), calc(var(--mouse-y, 0) * -1))',
          transition: 'transform 1.5s cubic-bezier(0.22,1,0.36,1)',
        }}
      />

      {/* SVG abstract geometric shapes */}
      <svg
        className="absolute inset-0 w-full h-full"
        viewBox="0 0 1200 800"
        preserveAspectRatio="xMidYMid slice"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <filter id="glow-gold" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          <linearGradient id="grad-gold-line" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#c9a96e" stopOpacity="0" />
            <stop offset="50%" stopColor="#c9a96e" stopOpacity="0.5" />
            <stop offset="100%" stopColor="#c9a96e" stopOpacity="0" />
          </linearGradient>
          <linearGradient id="grad-silver-line" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#c0c0c0" stopOpacity="0" />
            <stop offset="50%" stopColor="#c0c0c0" stopOpacity="0.3" />
            <stop offset="100%" stopColor="#c0c0c0" stopOpacity="0" />
          </linearGradient>
        </defs>

        {/* Concentric circles — top right */}
        <g
          style={{
            transform: 'translate(var(--mouse-x, 0), var(--mouse-y, 0))',
            transition: 'transform 2s cubic-bezier(0.22,1,0.36,1)',
          }}
        >
          <circle cx="950" cy="200" r="180" stroke="url(#grad-gold-line)" strokeWidth="1" opacity="0.4" />
          <circle cx="950" cy="200" r="140" stroke="url(#grad-gold-line)" strokeWidth="0.5" opacity="0.3" />
          <circle cx="950" cy="200" r="100" stroke="url(#grad-gold-line)" strokeWidth="0.5" opacity="0.2" />
          <circle cx="950" cy="200" r="60" stroke="#c9a96e" strokeWidth="0.5" opacity="0.3" filter="url(#glow-gold)" className="animate-shimmer" />
        </g>

        {/* Diagonal lines — left side */}
        <g
          style={{
            transform: 'translate(calc(var(--mouse-x, 0) * -0.5), calc(var(--mouse-y, 0) * -0.5))',
            transition: 'transform 2s cubic-bezier(0.22,1,0.36,1)',
          }}
        >
          <line x1="0" y1="650" x2="400" y2="250" stroke="url(#grad-silver-line)" strokeWidth="1" opacity="0.3" />
          <line x1="50" y1="700" x2="450" y2="300" stroke="url(#grad-silver-line)" strokeWidth="0.5" opacity="0.2" />
        </g>

        {/* Floating geometric shape — bottom right */}
        <g
          className="animate-float"
          style={{
            transformOrigin: '1050px 600px',
          }}
        >
          <rect
            x="1000"
            y="550"
            width="100"
            height="100"
            rx="2"
            stroke="url(#grad-gold-line)"
            strokeWidth="0.8"
            opacity="0.3"
            transform="rotate(15 1050 600)"
          />
          <rect
            x="1020"
            y="570"
            width="60"
            height="60"
            rx="1"
            stroke="#c9a96e"
            strokeWidth="0.5"
            opacity="0.2"
            transform="rotate(30 1050 600)"
          />
        </g>

        {/* Flowing architectural ribbons — kept on the right to preserve a clear reading zone */}
        <g className="atelier-ribbon" fill="none" stroke="url(#grad-gold-line)" strokeLinecap="round">
          <path d="M 760 760 C 860 570, 850 420, 1010 280 C 1080 218, 1140 190, 1220 176" strokeWidth="1.3" opacity="0.75" />
          <path d="M 800 800 C 920 590, 900 430, 1050 320 C 1120 268, 1160 245, 1240 230" strokeWidth="0.7" opacity="0.6" />
          <path d="M 720 760 C 820 610, 820 500, 930 390 C 1010 312, 1080 290, 1180 270" strokeWidth="0.45" opacity="0.6" />
        </g>
        <g className="atelier-ribbon atelier-ribbon-delayed" fill="none" stroke="url(#grad-silver-line)" strokeLinecap="round">
          <path d="M 680 780 C 790 620, 790 480, 900 350 C 980 255, 1070 205, 1190 160" strokeWidth="0.6" opacity="0.5" />
          <path d="M 860 800 C 980 620, 990 490, 1120 390 C 1170 350, 1210 330, 1260 320" strokeWidth="0.35" opacity="0.5" />
        </g>

        {/* Fine gold particles */}
        <g fill="#e8d5a8">
          {[...Array(18)].map((_, i) => {
            const x = 690 + ((i * 83) % 470);
            const y = 90 + ((i * 137) % 610);
            return <circle key={i} className="atelier-particle" cx={x} cy={y} r={i % 4 === 0 ? 1.8 : 1} style={{ animationDelay: `${(i % 7) * -0.7}s` }} />;
          })}
        </g>

        {/* Central vertical accent line */}
        <line
          x1="600"
          y1="0"
          x2="600"
          y2="800"
          stroke="url(#grad-gold-line)"
          strokeWidth="0.5"
          opacity="0.15"
        />

        {/* Dot grid — subtle background texture */}
        <g opacity="0.08">
          {[...Array(12)].map((_, i) =>
            [...Array(8)].map((_, j) => (
              <circle
                key={`${i}-${j}`}
                cx={i * 100 + 50}
                cy={j * 100 + 50}
                r="1"
                fill="#c9a96e"
              />
            ))
          )}
        </g>

        {/* Animated arc — sweeping element */}
        <g
          style={{
            transformOrigin: '200px 400px',
            animation: 'float 12s ease-in-out infinite',
          }}
        >
          <path
            d="M 100 400 A 100 100 0 0 1 300 400"
            stroke="url(#grad-gold-line)"
            strokeWidth="1"
            opacity="0.25"
          />
          <path
            d="M 130 400 A 70 70 0 0 1 270 400"
            stroke="url(#grad-gold-line)"
            strokeWidth="0.5"
            opacity="0.15"
          />
        </g>
      </svg>

      {/* Vignette */}
      <div className="absolute inset-0 bg-gradient-to-b from-obsidian/40 via-transparent to-obsidian" />
      <div className="absolute inset-0 bg-gradient-to-r from-obsidian/60 via-transparent to-obsidian/30" />
    </div>
  );
}
