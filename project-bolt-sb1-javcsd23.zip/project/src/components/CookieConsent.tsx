import { useState, useEffect } from 'react';
import { Cookie, X } from 'lucide-react';
import { getConsent, setConsent } from '@/lib/analytics';

export default function CookieConsent() {
  const [visible, setVisible] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    const consent = getConsent();
    if (consent === 'pending') {
      const timer = setTimeout(() => setVisible(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    setConsent('granted');
    setVisible(false);
    setDismissed(true);
  };

  const handleDecline = () => {
    setConsent('denied');
    setVisible(false);
    setDismissed(true);
  };

  if (!visible || dismissed) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-[60] animate-fade-up">
      <div className="container-lux pb-4">
        <div className="glass-elevated p-5 max-w-3xl mx-auto flex flex-col sm:flex-row items-start sm:items-center gap-4 rounded-sm relative">
          <Cookie size={22} strokeWidth={1.5} className="text-gold/50 shrink-0" />
          <div className="flex-1">
            <p className="text-sm font-sans font-light text-ivorySoft/60 leading-relaxed">
              We use cookies to understand how visitors use our website and improve your experience.
              We do not use cookies for advertising targeting. See our{' '}
              <a href="/privacy-policy" className="text-gold/80 hover:text-gold transition-colors duration-500">Privacy Policy</a>.
            </p>
          </div>
          <div className="flex gap-3 shrink-0">
            <button
              onClick={handleDecline}
              className="px-4 py-2 text-[11px] uppercase tracking-wider-2 font-sans font-light text-ivorySoft/40 hover:text-ivorySoft transition-colors duration-500"
            >
              Decline
            </button>
            <button
              onClick={handleAccept}
              className="btn-primary !px-5 !py-2 !text-[10px]"
            >
              Accept
            </button>
          </div>
          <button
            onClick={handleDecline}
            className="absolute top-3 right-3 text-ivorySoft/20 hover:text-ivorySoft/50 transition-colors duration-500"
            aria-label="Close"
          >
            <X size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}
