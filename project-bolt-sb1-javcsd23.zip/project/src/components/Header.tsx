import { Link, useLocation } from 'react-router-dom';
import { useState, useEffect, useRef } from 'react';
import { Menu, X, ShoppingBag, ChevronDown } from 'lucide-react';
import { navLinks, siteConfig } from '@/data/siteConfig';
import { useCart } from '@/context/CartContext';

export default function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [hidden, setHidden] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const location = useLocation();
  const { itemCount } = useCart();
  const lastScrollY = useRef(0);

  useEffect(() => {
    setMobileOpen(false);
    setOpenDropdown(null);
  }, [location.pathname]);

  useEffect(() => {
    const handleScroll = () => {
      const currentY = window.scrollY;
      setScrolled(currentY > 24);

      // Hide on scroll down, reveal on scroll up
      if (currentY > 200 && currentY > lastScrollY.current && !mobileOpen) {
        setHidden(true);
      } else {
        setHidden(false);
      }
      lastScrollY.current = currentY;
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [mobileOpen]);

  const isActive = (path: string) =>
    path === '/' ? location.pathname === '/' : location.pathname.startsWith(path);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-700 ease-luxury ${
        hidden ? '-translate-y-full' : 'translate-y-0'
      } ${
        scrolled
          ? 'bg-obsidian/80 backdrop-blur-xl border-b border-white/[0.06] py-3'
          : 'bg-transparent py-6'
      }`}
    >
      <div className="container-lux-full flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-3 group" aria-label={`${siteConfig.fullName} home`}>
          <span className="font-serif text-2xl tracking-wider-2 text-ivory group-hover:text-gold transition-colors duration-700 ease-luxury">
            {siteConfig.name}
          </span>
          <span className="hidden sm:block text-[9px] uppercase tracking-mega-wide text-gold/60 font-sans font-light mt-1 transition-opacity duration-500 group-hover:opacity-100 opacity-60">
            Digital Atelier
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-0.5" aria-label="Main navigation">
          {navLinks.map((link) => (
            <div
              key={link.path}
              className="relative"
              onMouseEnter={() => link.children && setOpenDropdown(link.path)}
              onMouseLeave={() => setOpenDropdown(null)}
            >
              <Link
                to={link.path}
                className={`flex items-center gap-1 px-4 py-2 text-[11px] uppercase tracking-wider-2 font-sans font-light transition-colors duration-500 ease-luxury ${
                  isActive(link.path) ? 'text-gold' : 'text-ivorySoft/70 hover:text-ivory'
                }`}
              >
                {link.label}
                {link.children && <ChevronDown size={10} className="opacity-40" />}
              </Link>
              {/* Dropdown */}
              {link.children && openDropdown === link.path && (
                <div className="absolute top-full left-0 pt-3">
                  <div className="glass-elevated py-3 min-w-[240px] rounded-sm animate-slide-down">
                    <div className="px-4 pb-2 mb-1 divider-fine" />
                    {link.children.map((child) => (
                      <Link
                        key={child.path}
                        to={child.path}
                        className="flex items-center justify-between px-4 py-2.5 text-[11px] uppercase tracking-wider-2 font-sans font-light text-ivorySoft/60 hover:text-gold transition-colors duration-300 group/child"
                      >
                        <span>{child.label}</span>
                        <span className="text-gold/0 group-hover/child:text-gold/40 transition-colors duration-300">→</span>
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </nav>

        {/* Right Actions */}
        <div className="flex items-center gap-5">
          <Link
            to="/cart"
            className="relative text-ivorySoft/70 hover:text-gold transition-colors duration-500 ease-luxury"
            aria-label="Shopping cart"
          >
            <ShoppingBag size={18} strokeWidth={1.5} />
            {itemCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-gold text-obsidian text-[9px] font-sans font-medium w-4 h-4 rounded-full flex items-center justify-center">
                {itemCount}
              </span>
            )}
          </Link>
          <Link
            to="/project-inquiry"
            className="hidden md:inline-flex btn-primary !px-6 !py-2.5 !text-[10px]"
          >
            Start a Project
          </Link>
          <button
            className="lg:hidden text-ivorySoft/70 hover:text-gold transition-colors duration-500"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X size={22} strokeWidth={1.5} /> : <Menu size={22} strokeWidth={1.5} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="lg:hidden bg-obsidian/98 backdrop-blur-2xl border-t border-white/[0.06] animate-slide-down">
          <nav className="container-lux py-8 flex flex-col gap-0.5" aria-label="Mobile navigation">
            {navLinks.map((link) => (
              <div key={link.path} className="border-b border-white/[0.03] last:border-0">
                <Link
                  to={link.path}
                  className={`block py-4 text-sm uppercase tracking-wider-2 font-sans font-light transition-colors ${
                    isActive(link.path) ? 'text-gold' : 'text-ivorySoft/80'
                  }`}
                >
                  {link.label}
                </Link>
                {link.children && (
                  <div className="pl-4 border-l border-gold/10 ml-1 mb-2">
                    {link.children.map((child) => (
                      <Link
                        key={child.path}
                        to={child.path}
                        className="block py-2.5 text-[11px] uppercase tracking-wider-2 font-sans font-light text-ivorySoft/50 hover:text-gold transition-colors"
                      >
                        {child.label}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
            <Link to="/project-inquiry" className="btn-primary mt-6 w-full">
              Start a Project
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
