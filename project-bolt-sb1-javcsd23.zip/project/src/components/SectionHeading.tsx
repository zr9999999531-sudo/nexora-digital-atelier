import type { ReactNode } from 'react';

interface SectionHeadingProps {
  eyebrow?: string;
  title: ReactNode;
  subtitle?: string;
  center?: boolean;
}

export default function SectionHeading({ eyebrow, title, subtitle, center }: SectionHeadingProps) {
  return (
    <div className={`mb-0 ${center ? 'text-center' : ''}`}>
      {eyebrow && (
        <p className="eyebrow mb-5">
          <span className="inline-block w-6 h-px bg-gold/30 align-middle mr-3" />
          {eyebrow}
        </p>
      )}
      <h2 className="heading-display text-3xl md:text-4xl lg:text-5xl mb-4 text-balance">{title}</h2>
      {subtitle && (
        <p className={`text-sm md:text-base text-ivorySoft/45 font-sans font-light leading-relaxed ${center ? 'max-w-2xl mx-auto' : 'max-w-2xl'}`}>
          {subtitle}
        </p>
      )}
    </div>
  );
}
