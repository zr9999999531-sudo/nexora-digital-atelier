import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { CartProvider } from '@/context/CartContext';
import ScrollToTop from '@/components/ScrollToTop';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import CookieConsent from '@/components/CookieConsent';
import Seo from '@/components/Seo';

import Home from '@/pages/Home';
import About from '@/pages/About';
import Services from '@/pages/Services';
import Pricing from '@/pages/Pricing';
import HowItWorks from '@/pages/HowItWorks';
import FAQ from '@/pages/FAQ';
import Contact from '@/pages/Contact';
import ProjectInquiry from '@/pages/ProjectInquiry';
import Shop from '@/pages/Shop';
import ProductDetail from '@/pages/ProductDetail';
import Portfolio from '@/pages/Portfolio';
import CaseStudy from '@/pages/CaseStudy';
import Blog from '@/pages/Blog';
import BlogPost from '@/pages/BlogPost';
import Cart from '@/pages/Cart';
import Checkout from '@/pages/Checkout';
import OrderConfirmation from '@/pages/OrderConfirmation';
import LandingPage from '@/pages/LandingPage';
import NotFound from '@/pages/NotFound';
import PrivacyPolicy from '@/pages/legal/PrivacyPolicy';
import Terms from '@/pages/legal/Terms';
import RefundPolicy from '@/pages/legal/RefundPolicy';

function App() {
  return (
    <BrowserRouter>
      <CartProvider>
        <ScrollToTop />
        <Seo />
        <div className="min-h-screen flex flex-col atelier-shell">
          <div className="atelier-ambient" aria-hidden="true" />
          <Header />
          <main className="flex-1">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/about" element={<About />} />
              <Route path="/services/:serviceId" element={<Services />} />
              <Route path="/pricing" element={<Pricing />} />
              <Route path="/how-it-works" element={<HowItWorks />} />
              <Route path="/faq" element={<FAQ />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/project-inquiry" element={<ProjectInquiry />} />
              <Route path="/shop" element={<Shop />} />
              <Route path="/shop/:category" element={<Shop />} />
              <Route path="/product/:slug" element={<ProductDetail />} />
              <Route path="/portfolio" element={<Portfolio />} />
              <Route path="/portfolio/:slug" element={<CaseStudy />} />
              <Route path="/blog" element={<Blog />} />
              <Route path="/blog/:slug" element={<BlogPost />} />
              <Route path="/cart" element={<Cart />} />
              <Route path="/checkout" element={<Checkout />} />
              <Route path="/order-confirmation" element={<OrderConfirmation />} />
              <Route path="/lp/:slug" element={<LandingPage />} />
              <Route path="/privacy-policy" element={<PrivacyPolicy />} />
              <Route path="/terms" element={<Terms />} />
              <Route path="/refund-policy" element={<RefundPolicy />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </main>
          <Footer />
        </div>
        <CookieConsent />
      </CartProvider>
    </BrowserRouter>
  );
}

export default App;
